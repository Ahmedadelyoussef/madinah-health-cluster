"use client"

import { useState } from "react"
import { CheckCircle, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"

const survey = {
  question: "ما رأيك في برامج التدريب الحالية؟",
  options: [
    { text: "ممتاز", votes: 45, percentage: 45 },
    { text: "جيد جداً", votes: 30, percentage: 30 },
    { text: "جيد", votes: 20, percentage: 20 },
    { text: "يحتاج تحسين", votes: 5, percentage: 5 },
  ],
  totalVotes: 100,
}

export function VotingSurvey() {
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [hasVoted, setHasVoted] = useState(false)

  const handleVote = () => {
    if (selectedOption !== null) {
      setHasVoted(true)
    }
  }

  return (
    <div className="bg-gradient-to-br from-[#0088cc]/5 to-white rounded-3xl p-6 shadow-lg border border-[#0088cc]/20 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-[#0088cc]/10 flex items-center justify-center">
          <BarChart3 className="w-6 h-6 text-[#0088cc]" />
        </div>
        <h2 className="text-xl font-bold text-[#006ba3]">استطلاع الرأي</h2>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 leading-relaxed">{survey.question}</h3>

        <div className="space-y-3">
          {survey.options.map((option, index) => (
            <div key={index}>
              {!hasVoted ? (
                <button
                  onClick={() => setSelectedOption(index)}
                  className={`w-full p-4 rounded-xl text-right transition-all ${
                    selectedOption === index
                      ? "bg-[#0088cc] text-white shadow-lg scale-105"
                      : "bg-white border border-gray-200 hover:border-[#0088cc] hover:shadow-md"
                  }`}
                >
                  <span className="font-medium">{option.text}</span>
                </button>
              ) : (
                <div className="relative">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-white border border-gray-200">
                    <span className="font-medium text-gray-700">{option.text}</span>
                    <span className="text-sm font-bold text-[#0088cc]">{option.percentage}%</span>
                  </div>
                  <div
                    className="absolute bottom-0 right-0 h-full bg-[#0088cc]/10 rounded-xl transition-all duration-1000"
                    style={{ width: `${option.percentage}%` }}
                  ></div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {!hasVoted ? (
        <Button
          onClick={handleVote}
          disabled={selectedOption === null}
          className="w-full bg-[#0088cc] hover:bg-[#006ba3]"
        >
          تصويت
        </Button>
      ) : (
        <div className="flex items-center justify-center gap-2 p-3 bg-green-50 rounded-xl">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <span className="text-sm font-medium text-green-700">تم التصويت بنجاح</span>
        </div>
      )}

      <p className="text-xs text-gray-500 text-center mt-4">{survey.totalVotes} موظف شارك في الاستطلاع</p>
    </div>
  )
}
