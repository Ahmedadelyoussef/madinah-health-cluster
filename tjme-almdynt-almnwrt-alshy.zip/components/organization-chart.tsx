"use client"

import { ChevronDown, Users, Home, Building2 } from "lucide-react"
import Image from "next/image"
import { useState } from "react"
import { Button } from "@/components/ui/button"

const orgData = {
  ceo: {
    id: "ceo",
    name: "ناصر بن محمد الحقباني", // تغيير اسم الرئيس التنفيذي
    title: "الرئيس التنفيذي",
    image: "/images/CO.jpg",
    employees: 179,
    department: "الإدارة التنفيذية",
    color: "#0088cc",
  },
  directors: [
    {
      id: "marketing",
      name: "نورة السلمان",
      title: "مدير التسويق والاتصال",
      image: "/saudi-team-member-2.jpg",
      employees: 45,
      department: "التسويق والاتصال",
      color: "#0088cc",
      team: [
        { name: "أحمد المالكي", title: "مدير العلاقات العامة", image: "/saudi-team-member-1.jpg", employees: 12 },
        { name: "فاطمة الزهراني", title: "مدير التسويق الرقمي", image: "/saudi-team-member-4.jpg", employees: 15 },
        { name: "محمد العتيبي", title: "مدير المحتوى", image: "/saudi-team-member-3.jpg", employees: 18 },
      ],
    },
    {
      id: "tourism",
      name: "عبدالله الشهري",
      title: "مدير التطوير السياحي",
      image: "/saudi-team-member-1.jpg",
      employees: 38,
      department: "التطوير السياحي",
      color: "#1fa39b",
      team: [
        { name: "سلطان القرني", title: "مدير المشاريع السياحية", image: "/saudi-team-member-5.jpg", employees: 20 },
        { name: "لينا الشمري", title: "مدير تجربة الزوار", image: "/saudi-team-member-6.jpg", employees: 18 },
      ],
    },
    {
      id: "hr",
      name: "سعد القحطاني",
      title: "مدير الموارد البشرية",
      image: "/saudi-team-member-5.jpg",
      employees: 22,
      department: "الموارد البشرية",
      color: "#5ba0ce",
      team: [
        { name: "ريم الغامدي", title: "مدير التوظيف", image: "/saudi-team-member-2.jpg", employees: 8 },
        { name: "عمر البلوي", title: "مدير التطوير الوظيفي", image: "/saudi-team-member-3.jpg", employees: 14 },
      ],
    },
    {
      id: "it",
      name: "خالد العمري",
      title: "مدير التقنية والمعلومات",
      image: "/saudi-team-member-3.jpg",
      employees: 31,
      department: "التقنية والمعلومات",
      color: "#ff6b35",
      team: [
        { name: "يوسف الحربي", title: "مدير البنية التحتية", image: "/saudi-team-member-1.jpg", employees: 12 },
        { name: "هند العمري", title: "مدير تطوير الأنظمة", image: "/saudi-team-member-4.jpg", employees: 19 },
      ],
    },
    {
      id: "finance",
      name: "ريم الدوسري",
      title: "مدير الشؤون المالية",
      image: "/saudi-team-member-6.jpg",
      employees: 28,
      department: "الشؤون المالية",
      color: "#8fc8df",
      team: [
        { name: "فيصل الشهري", title: "مدير المحاسبة", image: "/saudi-team-member-5.jpg", employees: 15 },
        { name: "منى القحطاني", title: "مدير الرقابة المالية", image: "/saudi-team-member-2.jpg", employees: 13 },
      ],
    },
    {
      id: "legal",
      name: "سارة الحربي",
      title: "مدير الشؤون القانونية",
      image: "/saudi-team-member-4.jpg",
      employees: 15,
      department: "الشؤون القانونية",
      color: "#a8d08d",
      team: [
        { name: "طارق الدوسري", title: "مستشار قانوني أول", image: "/saudi-team-member-1.jpg", employees: 8 },
        { name: "نوف السلمان", title: "مدير الامتثال", image: "/saudi-team-member-6.jpg", employees: 7 },
      ],
    },
  ],
}

export function OrganizationChart() {
  const [currentView, setCurrentView] = useState<"ceo" | string>("ceo")
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null)

  const getCurrentData = () => {
    if (currentView === "ceo") {
      return { head: orgData.ceo, team: orgData.directors }
    } else {
      const director = orgData.directors.find((d) => d.id === currentView)
      return { head: director, team: director?.team || [] }
    }
  }

  const { head, team } = getCurrentData()

  const handlePersonClick = (id: string) => {
    setCurrentView(id)
    setSelectedDepartment(id)
  }

  const handleBackToCEO = () => {
    setCurrentView("ceo")
    setSelectedDepartment(null)
  }

  return (
    <div className="bg-white rounded-3xl p-4 md:p-6 shadow-lg border border-gray-100 relative overflow-hidden pattern-overlay">
      <div className="flex flex-col gap-4 mb-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl md:text-2xl font-bold text-[#0088cc]">الهيكل التنظيمي</h2>
          {currentView !== "ceo" && (
            <Button
              onClick={handleBackToCEO}
              variant="outline"
              size="sm"
              className="border-[#0088cc] text-[#0088cc] hover:bg-[#0088cc] hover:text-white bg-transparent"
            >
              <Home className="w-4 h-4 ml-2" />
              العودة للرئيس
            </Button>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleBackToCEO}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
              currentView === "ceo"
                ? "bg-[#0088cc] text-white shadow-md"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            <Building2 className="w-4 h-4" />
            الإدارة التنفيذية
          </button>
          {orgData.directors.map((dept) => (
            <button
              key={dept.id}
              onClick={() => handlePersonClick(dept.id)}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentView === dept.id ? "text-white shadow-md" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
              style={{
                backgroundColor: currentView === dept.id ? dept.color : undefined,
              }}
            >
              {dept.department}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col items-center gap-6">
        {head && (
          <div className="relative">
            <div
              className="bg-white border-4 rounded-2xl p-4 md:p-6 shadow-lg hover:shadow-xl transition-all px-12 md:px-28"
              style={{ borderColor: `${head.color}30` }}
            >
              <div className="flex flex-col items-center gap-3">
                <div
                  className="w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-4 shadow-lg"
                  style={{ borderColor: head.color }}
                >
                  <Image
                    src={head.image || "/placeholder.svg"}
                    alt={head.name}
                    width={80}
                    height={80}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="text-center">
                  <h3 className="font-bold text-base md:text-lg mb-1 text-[#0088cc]">{head.name}</h3>
                  <p className="text-xs md:text-sm text-gray-600 mb-2">{head.title}</p>
                  <div
                    className="flex items-center justify-center gap-1 rounded-full px-3 py-1"
                    style={{ backgroundColor: `${head.color}15` }}
                  >
                    <Users className="w-3 h-3 md:w-4 md:h-4" style={{ color: head.color }} />
                    <span className="text-xs font-medium" style={{ color: head.color }}>
                      {head.employees} موظف
                    </span>
                  </div>
                </div>
              </div>
            </div>
            {team.length > 0 && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 w-0.5 h-8 bg-gray-300"></div>
            )}
          </div>
        )}

        {team.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 w-full">
            {team.map((member: any, index: number) => (
              <div key={index} className="flex flex-col items-center group">
                <div className="w-0.5 h-8 bg-gray-300"></div>
                <div
                  className={`w-full bg-white rounded-2xl p-3 md:p-4 shadow-md hover:shadow-xl transition-all border-2 ${
                    member.id ? "cursor-pointer" : ""
                  }`}
                  style={{ borderColor: member.color ? `${member.color}30` : "#e5e7eb" }}
                  onClick={() => member.id && handlePersonClick(member.id)}
                >
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className="w-12 h-12 md:w-16 md:h-16 rounded-full overflow-hidden shadow-md"
                      style={{
                        borderColor: member.color || "#0088cc",
                        borderWidth: "3px",
                        borderStyle: "solid",
                      }}
                    >
                      <Image
                        src={member.image || "/placeholder.svg"}
                        alt={member.name}
                        width={64}
                        height={64}
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <div className="text-center">
                      <h3 className="font-bold text-sm md:text-base mb-1 text-gray-800">{member.name}</h3>
                      <p className="text-xs text-gray-600 mb-2">{member.title}</p>
                      <div
                        className="flex items-center justify-center gap-1 rounded-full px-2 py-0.5"
                        style={{ backgroundColor: member.color ? `${member.color}15` : "#0088cc15" }}
                      >
                        <Users className="w-3 h-3" style={{ color: member.color || "#0088cc" }} />
                        <span className="text-xs font-medium" style={{ color: member.color || "#0088cc" }}>
                          {member.employees} موظف
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                {member.id && (
                  <button
                    className="mt-2 text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => handlePersonClick(member.id)}
                  >
                    <ChevronDown className="w-4 h-4 md:w-5 md:h-5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
