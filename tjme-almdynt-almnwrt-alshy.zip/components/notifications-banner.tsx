"use client"

import { useState, useEffect } from "react"
import { AlertCircle, Info, AlertTriangle, CheckCircle, ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

type NotificationType = "urgent" | "important" | "normal" | "info"

interface Notification {
  id: number
  title: string
  message: string
  type: NotificationType
  time: string
  isRead: boolean
}

const notifications: Notification[] = [
  {
    id: 1,
    title: "تحديث عاجل: اجتماع طارئ",
    message: "اجتماع طارئ مع الإدارة العليا الساعة 3 مساءً في القاعة الرئيسية",
    type: "urgent",
    time: "منذ 5 دقائق",
    isRead: false,
  },
  {
    id: 2,
    title: "موعد تسليم التقارير الشهرية",
    message: "آخر موعد لتسليم التقارير الشهرية هو نهاية الأسبوع",
    type: "important",
    time: "منذ 30 دقيقة",
    isRead: false,
  },
  {
    id: 3,
    title: "تهانينا! تم الموافقة على طلبك",
    message: "تمت الموافقة على طلب الإجازة الخاص بك من 15-20 يناير",
    type: "info",
    time: "منذ ساعة",
    isRead: true,
  },
  {
    id: 4,
    title: "تحديث النظام",
    message: "سيتم إجراء صيانة للنظام يوم السبت من 12-2 صباحاً",
    type: "normal",
    time: "منذ ساعتين",
    isRead: false,
  },
  {
    id: 5,
    title: "دورة تدريبية جديدة متاحة",
    message: "دورة القيادة الفعالة متاحة للتسجيل - عدد المقاعد محدود",
    type: "important",
    time: "منذ 3 ساعات",
    isRead: false,
  },
  {
    id: 6,
    title: "رسالة من الموارد البشرية",
    message: "يرجى تحديث بياناتك الشخصية في النظام",
    type: "normal",
    time: "منذ 4 ساعات",
    isRead: true,
  },
]

const typeConfig = {
  urgent: {
    bgColor: "from-red-50 to-red-100",
    borderColor: "border-red-300",
    iconBg: "bg-red-500",
    textColor: "text-red-700",
    icon: AlertCircle,
  },
  important: {
    bgColor: "from-orange-50 to-orange-100",
    borderColor: "border-orange-300",
    iconBg: "bg-orange-500",
    textColor: "text-orange-700",
    icon: AlertTriangle,
  },
  normal: {
    bgColor: "from-blue-50 to-blue-100",
    borderColor: "border-blue-300",
    iconBg: "bg-blue-500",
    textColor: "text-blue-700",
    icon: Info,
  },
  info: {
    bgColor: "from-green-50 to-green-100",
    borderColor: "border-green-300",
    iconBg: "bg-green-500",
    textColor: "text-green-700",
    icon: CheckCircle,
  },
}

export function NotificationsBanner() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [visibleCount, setVisibleCount] = useState(3)

  useEffect(() => {
    const updateVisibleCount = () => {
      if (window.innerWidth < 640) {
        setVisibleCount(1) // Mobile: 1 notification
      } else if (window.innerWidth < 1024) {
        setVisibleCount(2) // Tablet: 2 notifications
      } else {
        setVisibleCount(3) // Desktop: 3 notifications
      }
    }

    updateVisibleCount()
    window.addEventListener("resize", updateVisibleCount)
    return () => window.removeEventListener("resize", updateVisibleCount)
  }, [])

  const visibleNotifications = notifications.slice(currentIndex, currentIndex + visibleCount)

  useEffect(() => {
    const interval = setInterval(() => {
      handleNext()
    }, 5000)

    return () => clearInterval(interval)
  }, [currentIndex, visibleCount])

  const handleNext = () => {
    if (currentIndex + visibleCount < notifications.length) {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentIndex(currentIndex + visibleCount)
        setIsAnimating(false)
      }, 300)
    } else {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentIndex(0)
        setIsAnimating(false)
      }, 300)
    }
  }

  const handlePrev = () => {
    if (currentIndex - visibleCount >= 0) {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentIndex(currentIndex - visibleCount)
        setIsAnimating(false)
      }, 300)
    }
  }

  return (
    null
  )
}
