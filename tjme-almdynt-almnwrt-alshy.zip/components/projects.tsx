"use client"

import { Building2, MapPin, Calendar } from "lucide-react"

const projects = [
  {
    name: "توسعة المستشفى الرئيسي",
    location: "المدينة المنورة",
    progress: 75,
    status: "قيد التنفيذ",
    completion: "2024",
    image: "/hospital-exterior.jpg",
    color: "#0088cc",
  },
  {
    name: "مركز الرعاية الطارئة",
    location: "شرق المدينة",
    progress: 60,
    status: "قيد التنفيذ",
    completion: "2025",
    image: "/medical-team.jpg",
    color: "#1fa39b",
  },
  {
    name: "عيادات التخصصية",
    location: "غرب المدينة",
    progress: 45,
    status: "قيد التنفيذ",
    completion: "2025",
    image: "/patient-care.jpg",
    color: "#5ba0ce",
  },
  {
    name: "مركز التطعيم المجتمعي",
    location: "وسط المدينة",
    progress: 80,
    status: "قيد التنفيذ",
    completion: "2024",
    image: "/medical-technology.jpg",
    color: "#006ba3",
  },
]

export function Projects() {
  return (
    <div className="bg-gradient-to-br from-[#0088cc]/5 to-white rounded-3xl p-8 shadow-lg border border-[#0088cc]/20 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-[#0088cc]/10 flex items-center justify-center">
          <Building2 className="w-6 h-6 text-[#0088cc]" />
        </div>
        <h2 className="text-2xl font-bold text-[#006ba3]">المشاريع الصحية</h2>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {projects.map((project, index) => (
          <div
            key={index}
            className="group relative rounded-2xl overflow-hidden bg-white border border-gray-100 hover:shadow-xl transition-all"
          >
            <div className="relative h-40">
              <img
                src={project.image || "/placeholder.svg"}
                alt={project.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>

              <div className="absolute bottom-3 left-3 right-3">
                <h3 className="text-white font-bold text-lg mb-1">{project.name}</h3>
                <div className="flex items-center gap-1 text-white/90 text-sm">
                  <MapPin className="w-4 h-4" />
                  <span>{project.location}</span>
                </div>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <span
                  className="px-3 py-1 rounded-lg text-xs font-bold text-white"
                  style={{ backgroundColor: project.color }}
                >
                  {project.status}
                </span>
                <div className="flex items-center gap-1 text-sm text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span>{project.completion}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">نسبة الإنجاز</span>
                  <span className="font-bold" style={{ color: project.color }}>
                    {project.progress}%
                  </span>
                </div>
                <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="absolute top-0 right-0 h-full rounded-full transition-all duration-1000"
                    style={{
                      width: `${project.progress}%`,
                      backgroundColor: project.color,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
