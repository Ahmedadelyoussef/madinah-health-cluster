"use client"

import { useState, useEffect } from "react"
import { Smile, Meh, Frown, X, Sparkles } from "lucide-react"

export function MoodPopup() {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedMood, setSelectedMood] = useState<string | null>(null)
  const [showResponse, setShowResponse] = useState(false)

  useEffect(() => {
    // Show popup after 1 second of page load
    const timer = setTimeout(() => {
      setIsOpen(true)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const moods = [
    {
      id: "happy",
      icon: Smile,
      label: "سعيد",
      color: "from-green-400 to-emerald-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-300",
      textColor: "text-green-700",
      response: "🌟 رائع! نتمنى لك يوماً مليئاً بالإنجازات والنجاح!",
    },
    {
      id: "neutral",
      icon: Meh,
      label: "عادي",
      color: "from-blue-400 to-cyan-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-300",
      textColor: "text-blue-700",
      response: "💙 يوم عادي، وهذا جيد! نأمل أن نجعله أفضل لك.",
    },
    {
      id: "sad",
      icon: Frown,
      label: "حزين",
      color: "from-orange-400 to-red-500",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-300",
      textColor: "text-orange-700",
      response: "🤗 نأسف لسماع ذلك. نحن هنا لدعمك، لا تتردد في التواصل معنا.",
    },
  ]

  const handleMoodSelect = (mood: (typeof moods)[0]) => {
    setSelectedMood(mood.id)
    setShowResponse(true)

    // Close popup after showing response
    setTimeout(() => {
      setIsOpen(false)
    }, 3000)
  }

  const handleClose = () => {
    setIsOpen(false)
  }

  if (!isOpen) return null

  const selectedMoodData = moods.find((m) => m.id === selectedMood)

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl shadow-2xl border-4 border-[#0088cc]/20 p-8 max-w-md w-full mx-4 animate-in zoom-in-95 duration-300">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {!showResponse ? (
          <>
            {/* Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-[#0088cc] to-[#006ba3] mb-4">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-[#0088cc] mb-2">كيف تشعر اليوم؟</h2>
              <p className="text-gray-600">نحب أن نعرف شعورك لنقدم لك أفضل تجربة</p>
            </div>

            {/* Mood Options */}
            <div className="grid grid-cols-3 gap-4">
              {moods.map((mood) => {
                const Icon = mood.icon
                return (
                  <button
                    key={mood.id}
                    onClick={() => handleMoodSelect(mood)}
                    className={`${mood.bgColor} ${mood.borderColor} border-2 rounded-2xl p-6 flex flex-col items-center gap-3 hover:scale-105 hover:shadow-lg transition-all duration-200 group`}
                  >
                    <div
                      className={`w-16 h-16 rounded-full bg-gradient-to-br ${mood.color} flex items-center justify-center group-hover:scale-110 transition-transform`}
                    >
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <span className={`font-bold ${mood.textColor}`}>{mood.label}</span>
                  </button>
                )
              })}
            </div>
          </>
        ) : (
          <div className="text-center py-8 animate-in fade-in zoom-in-95 duration-300">
            {selectedMoodData && (
              <>
                <div
                  className={`inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br ${selectedMoodData.color} mb-6 animate-pulse`}
                >
                  <selectedMoodData.icon className="w-12 h-12 text-white" />
                </div>
                <p className="text-2xl font-bold text-[#0088cc] leading-relaxed">{selectedMoodData.response}</p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
