"use client"

import { CheckCircle2, Circle, Play, FileText, Video } from "lucide-react"
import { Button } from "@/components/ui/button"

const onboardingSteps = [
  {
    title: "مرحباً بك في الهيئة",
    description: "شاهد فيديو تعريفي عن الهيئة ورؤيتها",
    type: "video",
    duration: "5 دقائق",
    completed: true,
    color: "#51c041",
  },
  {
    title: "سياسات وإجراءات العمل",
    description: "تعرف على سياسات العمل والإجراءات المتبعة",
    type: "document",
    duration: "15 دقيقة",
    completed: true,
    color: "#009aac",
  },
  {
    title: "الأنظمة والأدوات",
    description: "دليل استخدام الأنظمة الداخلية والأدوات",
    type: "video",
    duration: "10 دقائق",
    completed: false,
    color: "#be008d",
  },
  {
    title: "الصحة والسلامة",
    description: "إرشادات السلامة في بيئة العمل",
    type: "document",
    duration: "8 دقائق",
    completed: false,
    color: "#ff8300",
  },
  {
    title: "ثقافة المؤسسة",
    description: "قيمنا وثقافتنا التنظيمية",
    type: "video",
    duration: "7 دقائق",
    completed: false,
    color: "#ff424c",
  },
]

export function DigitalOnboard() {
  const completedSteps = onboardingSteps.filter((step) => step.completed).length
  const progress = (completedSteps / onboardingSteps.length) * 100

  return (
    <div className="bg-gradient-to-br from-[#51c041]/5 to-white rounded-3xl p-4 sm:p-6 lg:p-8 shadow-lg border border-[#51c041]/20 relative overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#3e6e2d] mb-2">التهيئة الرقمية</h2>
          <p className="text-xs sm:text-sm text-gray-600">
            أكملت {completedSteps} من {onboardingSteps.length} خطوات
          </p>
        </div>

        <div className="relative w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24">
          <svg className="transform -rotate-90" width="100%" height="100%" viewBox="0 0 96 96">
            <circle cx="48" cy="48" r="40" stroke="#e5e7eb" strokeWidth="8" fill="none" />
            <circle
              cx="48"
              cy="48"
              r="40"
              stroke="#51c041"
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${2 * Math.PI * 40}`}
              strokeDashoffset={`${2 * Math.PI * 40 * (1 - progress / 100)}`}
              strokeLinecap="round"
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-lg sm:text-xl lg:text-2xl font-bold text-[#51c041]">{Math.round(progress)}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4">
        {onboardingSteps.map((step, index) => (
          <div
            key={index}
            className={`group relative p-4 sm:p-5 rounded-2xl border-2 transition-all hover:shadow-xl ${
              step.completed ? "bg-white border-green-200" : "bg-white border-gray-200 hover:border-gray-300"
            }`}
          >
            <div className="flex flex-col h-full">
              <div className="flex items-start justify-between mb-3 sm:mb-4">
                <div
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: `${step.color}20` }}
                >
                  {step.type === "video" ? (
                    <Video className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: step.color }} />
                  ) : (
                    <FileText className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: step.color }} />
                  )}
                </div>
                {step.completed ? (
                  <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-green-500" />
                ) : (
                  <Circle className="w-5 h-5 sm:w-6 sm:h-6 text-gray-300" />
                )}
              </div>

              <h3 className="font-bold text-sm sm:text-base text-gray-800 mb-2 leading-snug">{step.title}</h3>
              <p className="text-xs sm:text-sm text-gray-600 mb-3 sm:mb-4 flex-1 leading-relaxed">{step.description}</p>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">{step.duration}</span>
                {!step.completed && (
                  <Button
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-xs"
                    style={{ backgroundColor: step.color }}
                  >
                    <Play className="w-3 h-3 ml-1" />
                    <span className="hidden sm:inline">ابدأ</span>
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
