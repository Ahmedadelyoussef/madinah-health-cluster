"use client"

import { useState } from "react"
import Image from "next/image"
import { MessageSquare, ThumbsUp, Send, MoreVertical, Users, Plus, X, ImageIcon, Smile, Hash } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Post {
  id: number
  author: {
    name: string
    image: string
    role: string
  }
  content: string
  timestamp: string
  likes: number
  comments: number
  isLiked: boolean
  category: string
}

export function DiscussionBoard() {
  const [posts, setPosts] = useState<Post[]>([
    {
      id: 1,
      author: {
        name: "سارة الغامدي",
        image: "/saudi-team-member-2.jpg",
        role: "مدير التسويق",
      },
      content:
        "مبروك للفريق على إطلاق الحملة التسويقية الجديدة! 🎉 النتائج الأولية تبدو رائعة والتفاعل مع الجمهور كان ممتازاً. شكراً لكل من ساهم في إنجاح هذا المشروع.",
      timestamp: "منذ ساعتين",
      likes: 24,
      comments: 8,
      isLiked: false,
      category: "إعلانات",
    },
    {
      id: 2,
      author: {
        name: "محمد العتيبي",
        image: "/saudi-team-member-1.jpg",
        role: "مطور برمجيات",
      },
      content:
        "هل يوجد أحد لديه خبرة في تطوير تطبيقات React Native؟ أحتاج بعض المساعدة في مشروع جديد. يرجى التواصل معي لو كان لديكم وقت للمساعدة.",
      timestamp: "منذ 4 ساعات",
      likes: 12,
      comments: 15,
      isLiked: true,
      category: "أسئلة",
    },
    {
      id: 3,
      author: {
        name: "فاطمة الشهري",
        image: "/saudi-team-member-4.jpg",
        role: "محلل بيانات",
      },
      content:
        "تقرير الربع الثالث جاهز الآن! يمكنكم الاطلاع عليه من خلال مركز الموارد. التحليلات تُظهر نمواً ملحوظاً في جميع المؤشرات الرئيسية. مبروك للجميع! 📊",
      timestamp: "منذ 6 ساعات",
      likes: 31,
      comments: 5,
      isLiked: true,
      category: "تحديثات",
    },
    {
      id: 4,
      author: {
        name: "خالد السعيد",
        image: "/saudi-team-member-3.jpg",
        role: "منسق فعاليات",
      },
      content:
        "لا تنسوا التسجيل في فعالية تطوير الذات يوم الخميس القادم! سيكون لدينا متحدثون رائعون وورش عمل تفاعلية. المقاعد محدودة.",
      timestamp: "منذ يوم واحد",
      likes: 18,
      comments: 12,
      isLiked: false,
      category: "فعاليات",
    },
    {
      id: 5,
      author: {
        name: "نورة المطيري",
        image: "/saudi-team-member-5.jpg",
        role: "مدير موارد بشرية",
      },
      content:
        "تذكير: آخر موعد لتقديم طلبات الإجازات السنوية هو نهاية الأسبوع. يرجى التنسيق مع مديريكم المباشرين والتأكد من إكمال جميع الإجراءات.",
      timestamp: "منذ يومين",
      likes: 45,
      comments: 3,
      isLiked: false,
      category: "إعلانات",
    },
  ])

  const [isNewPostOpen, setIsNewPostOpen] = useState(false)
  const [newPostContent, setNewPostContent] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("الكل")

  const categories = ["الكل", "إعلانات", "أسئلة", "تحديثات", "فعاليات", "عام"]

  const handleLike = (postId: number) => {
    setPosts(
      posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              likes: post.isLiked ? post.likes - 1 : post.likes + 1,
              isLiked: !post.isLiked,
            }
          : post,
      ),
    )
  }

  const handleNewPost = () => {
    if (newPostContent.trim()) {
      const newPost: Post = {
        id: posts.length + 1,
        author: {
          name: "أحمد المالكي",
          image: "/saudi-man-traditional-thobe-professional.jpg",
          role: "مدير تقنية المعلومات",
        },
        content: newPostContent,
        timestamp: "الآن",
        likes: 0,
        comments: 0,
        isLiked: false,
        category: "عام",
      }
      setPosts([newPost, ...posts])
      setNewPostContent("")
      setIsNewPostOpen(false)
    }
  }

  const filteredPosts = selectedCategory === "الكل" ? posts : posts.filter((post) => post.category === selectedCategory)

  return (
    <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden pattern-overlay h-[450px] flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#0088cc] to-[#006ba3] p-3 text-white">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold">لوحة النقاش</h3>
              <p className="text-xs text-white/80">شارك أفكارك مع الفريق</p>
            </div>
          </div>
          <Button
            onClick={() => setIsNewPostOpen(true)}
            className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/40 text-xs h-8"
          >
            <Plus className="w-3 h-3 ml-1" />
            منشور جديد
          </Button>
        </div>

        {/* Categories Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-3 py-1 rounded-full text-xs whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? "bg-white text-[#0088cc] font-semibold shadow-md"
                  : "bg-white/10 hover:bg-white/20 border border-white/30"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Posts Feed */}
      <div className="flex-1 p-3 space-y-2.5 overflow-y-auto scrollbar-thin scrollbar-thumb-[#0088cc]/20 scrollbar-track-gray-100">
        {filteredPosts.map((post) => (
          <div
            key={post.id}
            className="bg-gradient-to-br from-gray-50 to-white p-2.5 rounded-2xl border border-gray-200 hover:shadow-md transition-all"
          >
            {/* Post Header */}
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <Image
                  src={post.author.image || "/placeholder.svg"}
                  alt={post.author.name}
                  width={36}
                  height={36}
                  className="rounded-full border-2 border-[#0088cc]/30"
                />
                <div>
                  <h4 className="font-semibold text-sm text-gray-900">{post.author.name}</h4>
                  <p className="text-xs text-gray-500">{post.author.role}</p>
                  <p className="text-xs text-gray-400">{post.timestamp}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-0.5 bg-gradient-to-r from-[#0088cc]/10 to-[#006ba3]/10 text-[#0088cc] text-xs font-medium rounded-full">
                  {post.category}
                </span>
                <button className="text-gray-400 hover:text-gray-600">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Post Content */}
            <p className="text-sm text-gray-700 mb-2 leading-relaxed">{post.content}</p>

            {/* Post Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-gray-200">
              <button
                onClick={() => handleLike(post.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs transition-all ${
                  post.isLiked
                    ? "bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                <ThumbsUp className="w-3 h-3" />
                <span className="font-medium">{post.likes}</span>
              </button>
              <button className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all">
                <MessageSquare className="w-3 h-3" />
                <span className="font-medium">{post.comments}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* New Post Modal */}
      {isNewPostOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in slide-in-from-bottom-4">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-[#0088cc] to-[#006ba3] p-6 text-white">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">إنشاء منشور جديد</h3>
                <button
                  onClick={() => setIsNewPostOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <div className="flex items-start gap-3 mb-4">
                <Image
                  src="/saudi-man-traditional-thobe-professional.jpg"
                  alt="أحمد المالكي"
                  width={48}
                  height={48}
                  className="rounded-full border-2 border-[#0088cc]/30"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">أحمد المالكي</h4>
                  <p className="text-xs text-gray-500">مدير تقنية المعلومات</p>
                </div>
              </div>

              <textarea
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder="ماذا تريد أن تشارك مع فريقك؟"
                className="w-full h-40 p-4 border border-gray-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-[#0088cc]/50 text-gray-700"
              />

              {/* Action Buttons */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-all">
                    <ImageIcon className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-all">
                    <Smile className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 transition-all">
                    <Hash className="w-5 h-5" />
                  </button>
                </div>
                <Button
                  onClick={handleNewPost}
                  disabled={!newPostContent.trim()}
                  className="bg-gradient-to-r from-[#0088cc] to-[#006ba3] hover:opacity-90"
                >
                  <Send className="w-4 h-4 ml-2" />
                  نشر
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
