"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const slides = [
  {
    title: "مرحباً بك في بوابة تجمع المدينة المنورة الصحي",
    subtitle: "منصتك الموحدة للوصول لجميع الخدمات والموارد الصحية",
    video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/health%20cluster-ZaoQ6S44DEyVnOhcKjRpy6bjkoh8LK.mp4",
    color: "#0088cc",
  },
  {
    title: "استكشف الفرص الوظيفية الجديدة",
    subtitle: "انضم إلى فريقنا وكن جزءاً من منظومة الرعاية الصحية",
    video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/health%20cluster-ZaoQ6S44DEyVnOhcKjRpy6bjkoh8LK.mp4",
    color: "#1fa39b",
  },
  {
    title: "رعاية صحية متميزة في المدينة المنورة",
    subtitle: "نلتزم بتقديم أفضل خدمات الرعاية الصحية",
    video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/health%20cluster-ZaoQ6S44DEyVnOhcKjRpy6bjkoh8LK.mp4",
    color: "#0088cc",
  },
  {
    title: "تطوير مهاراتك مع برامجنا التدريبية",
    subtitle: "اكتشف دورات تدريبية متنوعة لتطوير قدراتك الطبية",
    video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/health%20cluster-ZaoQ6S44DEyVnOhcKjRpy6bjkoh8LK.mp4",
    color: "#5ba0ce",
  },
]

export function HeroBanner() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length)
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)

  return (
    <div className="relative h-[280px] sm:h-[350px] md:h-[400px] lg:h-[420px] overflow-hidden rounded-2xl md:rounded-3xl z-0">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-all duration-700 ${
            index === currentSlide ? "opacity-100 scale-100" : "opacity-0 scale-105"
          }`}
        >
          <div className="relative h-full">
            <video src={slide.video} autoPlay loop muted playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent"></div>

            <div className="absolute inset-0 flex items-center">
              <div className="max-w-[1600px] mx-auto px-4 sm:px-6 w-full">
                <div className="max-w-xl md:max-w-2xl">
                  <h1
                    className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-2 sm:mb-3 md:mb-4 animate-fade-in-up drop-shadow-lg"
                    style={{ animationDelay: "200ms" }}
                  >
                    {slide.title}
                  </h1>
                  <p
                    className="text-sm sm:text-base md:text-lg lg:text-xl text-white/90 mb-4 sm:mb-6 md:mb-8 animate-fade-in-up drop-shadow line-clamp-2 sm:line-clamp-none"
                    style={{ animationDelay: "400ms" }}
                  >
                    {slide.subtitle}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation */}
      <div className="absolute bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 flex gap-1.5 md:gap-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`h-1.5 md:h-2 rounded-full transition-all ${
              index === currentSlide ? "bg-white w-6 md:w-8" : "bg-white/50 w-1.5 md:w-2"
            }`}
          />
        ))}
      </div>

      {/* Arrow Navigation */}
      <Button
        variant="ghost"
        size="icon"
        onClick={prevSlide}
        className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white z-20 w-8 h-8 md:w-10 md:h-10 hidden sm:flex"
      >
        <ChevronLeft className="w-4 h-4 md:w-6 md:h-6" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={nextSlide}
        className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white z-20 w-8 h-8 md:w-10 md:h-10 hidden sm:flex"
      >
        <ChevronRight className="w-4 h-4 md:w-6 md:h-6" />
      </Button>
    </div>
  )
}
