"use client"

import { FileText, Download, Search, Folder } from "lucide-react"
import { Button } from "@/components/ui/button"

const resources = [
  { name: "دليل الموظف 2024", type: "PDF", size: "2.4 MB", downloads: 234, color: "#ff424c" },
  { name: "سياسات الموارد البشرية", type: "PDF", size: "1.8 MB", downloads: 189, color: "#51c041" },
  { name: "نماذج الطلبات", type: "ZIP", size: "5.2 MB", downloads: 412, color: "#009aac" },
  { name: "إرشادات العمل عن بعد", type: "PDF", size: "890 KB", downloads: 156, color: "#be008d" },
  { name: "دليل الهوية البصرية", type: "PDF", size: "12 MB", downloads: 98, color: "#ff8300" },
  { name: "قوالب العروض التقديمية", type: "ZIP", size: "8.6 MB", downloads: 267, color: "#5d892f" },
]

export function Resources() {
  return (
    <div className="bg-white rounded-3xl p-6 shadow-lg border border-gray-100 h-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#51c041]/10 flex items-center justify-center">
            <Folder className="w-6 h-6 text-[#51c041]" />
          </div>
          <h2 className="text-xl font-bold text-[#3e6e2d]">الموارد</h2>
        </div>

        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="ابحث..."
            className="w-48 pr-10 pl-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#51c041] text-sm"
          />
        </div>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {resources.map((resource, index) => (
          <div
            key={index}
            className="group flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-white hover:shadow-md transition-all border border-transparent hover:border-gray-200"
          >
            <div
              className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: `${resource.color}20` }}
            >
              <FileText className="w-6 h-6" style={{ color: resource.color }} />
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-gray-800 mb-1 truncate">{resource.name}</h3>
              <div className="flex items-center gap-3 text-xs text-gray-500">
                <span>{resource.type}</span>
                <span>•</span>
                <span>{resource.size}</span>
                <span>•</span>
                <span>{resource.downloads} تنزيل</span>
              </div>
            </div>

            <Button size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity">
              <Download className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  )
}
