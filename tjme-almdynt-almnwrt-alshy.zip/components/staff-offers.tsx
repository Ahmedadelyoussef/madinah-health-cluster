"use client"

import { Tag, Clock, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"

const offers = [
  {
    title: "خصم 30% على رحلات الطيران",
    provider: "الخطوط السعودية",
    discount: "30%",
    validUntil: "حتى 31 مارس",
    category: "سفر",
    image: "/saudi-airlines-airplane-flying-sky.jpg",
    color: "#51c041",
  },
  {
    title: "خصم 25% على الفنادق",
    provider: "سلسلة فنادق روتانا",
    discount: "25%",
    validUntil: "حتى 30 أبريل",
    category: "إقامة",
    image: "/luxury-hotel-lobby-saudi-arabia-rotana.jpg",
    color: "#009aac",
  },
  {
    title: "خصم 20% على المطاعم",
    provider: "مجموعة مطاعم العثيم",
    discount: "20%",
    validUntil: "حتى 15 أبريل",
    category: "مطاعم",
    image: "/arabic-restaurant-fine-dining-saudi-cuisine.jpg",
    color: "#ff8300",
  },
  {
    title: "خصم 15% على المشتريات",
    provider: "مراكز التسوق الكبرى",
    discount: "15%",
    validUntil: "حتى نهاية الشهر",
    category: "تسوق",
    image: "/modern-shopping-mall-interior-saudi-arabia.jpg",
    color: "#be008d",
  },
]

export function StaffOffers() {
  return (
    <div className="bg-gradient-to-br from-[#ff8300]/5 to-white rounded-3xl p-8 shadow-lg border border-[#ff8300]/20 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-[#ff8300]/10 flex items-center justify-center">
          <Tag className="w-6 h-6 text-[#ff8300]" />
        </div>
        <h2 className="text-2xl font-bold text-[#3e6e2d]">عروض الموظفين</h2>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {offers.map((offer, index) => (
          <div
            key={index}
            className="group relative rounded-2xl overflow-hidden bg-white border border-gray-100 hover:shadow-xl transition-all"
          >
            <div className="relative h-40">
              <img
                src={offer.image || "/placeholder.svg"}
                alt={offer.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>

              <div
                className="absolute top-3 right-3 w-16 h-16 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg backdrop-blur-sm"
                style={{ backgroundColor: `${offer.color}dd` }}
              >
                {offer.discount}
              </div>

              <button className="absolute top-3 left-3 w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors">
                <Heart className="w-5 h-5 text-white" />
              </button>
            </div>

            <div className="p-4">
              <span
                className="inline-block px-2 py-1 rounded-lg text-xs font-bold text-white mb-2"
                style={{ backgroundColor: offer.color }}
              >
                {offer.category}
              </span>

              <h3 className="font-bold text-gray-800 mb-1">{offer.title}</h3>
              <p className="text-sm text-gray-600 mb-3">{offer.provider}</p>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{offer.validUntil}</span>
                </div>
                <Button
                  size="sm"
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ backgroundColor: offer.color }}
                >
                  احصل عليه
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
