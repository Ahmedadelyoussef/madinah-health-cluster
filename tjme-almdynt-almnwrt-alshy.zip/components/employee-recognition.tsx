"use client"

import { Award, Star, Trophy, TrendingUp } from "lucide-react"
import Image from "next/image"

const recognitions = [
  {
    name: "سارة أحمد القحطاني",
    achievement: "موظف الشهر - مارس 2024",
    description: "تميز في خدمة العملاء وتحقيق أعلى نسبة رضا",
    image: "/images/recognition-employee-1.jpg",
    icon: Trophy,
    color: "#ff8300",
  },
  {
    name: "محمد سعيد الدوسري",
    achievement: "جائزة الابتكار",
    description: "تطوير نظام جديد لتحسين كفاءة العمل",
    image: "/images/recognition-employee-2.jpg",
    icon: Star,
    color: "#51c041",
  },
  {
    name: "نورة عبدالعزيز",
    achievement: "التميز في القيادة",
    description: "قيادة فريق المشروع لتحقيق أهداف استثنائية",
    image: "/images/recognition-employee-3.jpg",
    icon: TrendingUp,
    color: "#009aac",
  },
]

export function EmployeeRecognition() {
  return (
    <div className="bg-gradient-to-br from-amber-50 to-white rounded-3xl p-8 shadow-lg border border-amber-200 h-full relative overflow-hidden">
      {/* Shine effect */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent animate-pulse"></div>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg">
          <Award className="w-6 h-6 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-[#3e6e2d]">تقدير الموظفين</h2>
      </div>

      <div className="space-y-4">
        {recognitions.map((person, index) => (
          <div
            key={index}
            className="group relative p-5 rounded-2xl bg-white border border-gray-100 hover:shadow-xl hover:scale-102 transition-all"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="flex items-start gap-4">
              <div className="relative">
                <div className="w-20 h-20 rounded-2xl overflow-hidden ring-4 ring-amber-100 group-hover:ring-amber-200 transition-all">
                  <Image
                    src={person.image || "/placeholder.svg"}
                    alt={person.name}
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div
                  className="absolute -bottom-2 -right-2 w-10 h-10 rounded-xl flex items-center justify-center shadow-lg"
                  style={{ backgroundColor: person.color }}
                >
                  <person.icon className="w-5 h-5 text-white" />
                </div>
              </div>

              <div className="flex-1">
                <h3 className="font-bold text-gray-800 text-lg mb-1">{person.name}</h3>
                <p className="text-sm font-bold mb-2" style={{ color: person.color }}>
                  {person.achievement}
                </p>
                <p className="text-sm text-gray-600 leading-relaxed">{person.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
