"use client"

import {
  Twitter,
  Instagram,
  Linkedin,
  Youtube,
  Phone,
  Mail,
  HeadphonesIcon,
  Users,
  Briefcase,
  FileText,
  Calendar,
  Clock,
  HelpCircle,
  MessageSquare,
  Shield,
} from "lucide-react"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="relative mt-16 overflow-hidden">
      {/* Pattern Background */}
      <div className="absolute inset-0 opacity-5">
        <Image src="/images/pattern-202.jpg" alt="pattern" fill className="object-cover" />
      </div>

      <div className="relative bg-gradient-to-br from-[#0088cc] via-[#006ba3] to-[#0088cc]">
        <div className="max-w-[1600px] mx-auto px-6 py-12">
          <div className="text-center mb-10">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Image
                src="/logo.png"
                alt="تجمع المدينة المنورة الصحي"
                width={180}
                height={60}
                className="brightness-0 invert opacity-95"
              />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">بوابة موظفي تجمع المدينة المنورة الصحي</h2>
            <p className="text-white/70 text-sm">نعمل معاً لتقديم رعاية صحية متميزة</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* قسم الموارد البشرية */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-5 border border-white/20 hover:bg-white/15 transition-all hover:shadow-xl">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a8d08d] to-[#8bc97a] flex items-center justify-center shadow-lg">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white">الموارد البشرية</h3>
              </div>
              <ul className="space-y-2.5">
                <li className="flex items-start gap-2 text-white/90 text-sm group">
                  <Phone className="w-4 h-4 text-[#a8d08d] mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white/95">هاتف HR</div>
                    <a href="tel:+966148470000" className="hover:text-[#a8d08d] transition-colors">
                      +966 14 847-0000
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-2 text-white/90 text-sm">
                  <Mail className="w-4 h-4 text-[#a8d08d] mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white/95">إيميل HR</div>
                    <a href="mailto:hr@health.sa" className="hover:text-[#a8d08d] transition-colors break-all">
                      hr@health.sa
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-2 text-white/90 text-sm">
                  <Clock className="w-4 h-4 text-[#a8d08d] mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white/95">ساعات العمل</div>
                    <div>الأحد - الخميس: 7 ص - 3 م</div>
                  </div>
                </li>
              </ul>
            </div>

            {/* الدعم التقني */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-5 border border-white/20 hover:bg-white/15 transition-all hover:shadow-xl">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1fa39b] to-[#188d86] flex items-center justify-center shadow-lg">
                  <HeadphonesIcon className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white">الدعم التقني</h3>
              </div>
              <ul className="space-y-2.5">
                <li className="flex items-start gap-2 text-white/90 text-sm">
                  <Phone className="w-4 h-4 text-[#1fa39b] mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white/95">الهاتف المباشر</div>
                    <a href="tel:920027777" className="hover:text-[#1fa39b] transition-colors">
                      920027777
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-2 text-white/90 text-sm">
                  <Mail className="w-4 h-4 text-[#1fa39b] mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-white/95">دعم تقني</div>
                    <a href="mailto:itsupport@health.sa" className="hover:text-[#1fa39b] transition-colors break-all">
                      itsupport@health.sa
                    </a>
                  </div>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center gap-2 text-white/90 hover:text-[#1fa39b] transition-colors text-sm group"
                  >
                    <MessageSquare className="w-4 h-4 text-[#1fa39b] group-hover:scale-110 transition-transform" />
                    <span>محادثة مباشرة</span>
                  </a>
                </li>
              </ul>
            </div>

            {/* روابط سريعة للموظفين */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-5 border border-white/20 hover:bg-white/15 transition-all hover:shadow-xl">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8fc8df] to-[#7ab8d3] flex items-center justify-center shadow-lg">
                  <Briefcase className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white">خدمات الموظفين</h3>
              </div>
              <ul className="space-y-2">
                {[
                  { name: "طلب إجازة", icon: Calendar },
                  { name: "شهادات العمل", icon: FileText },
                  { name: "الرواتب والبدلات", icon: Briefcase },
                  { name: "دليل الموظفين", icon: Users },
                  { name: "السياسات واللوائح", icon: Shield },
                ].map((link, idx) => {
                  const Icon = link.icon
                  return (
                    <li key={idx}>
                      <a
                        href="#"
                        className="text-white/90 hover:text-[#8fc8df] transition-colors flex items-center gap-2 group text-sm"
                      >
                        <Icon className="w-4 h-4 text-[#8fc8df]/70 group-hover:text-[#8fc8df] group-hover:scale-110 transition-all" />
                        {link.name}
                      </a>
                    </li>
                  )
                })}
              </ul>
            </div>

            {/* معلومات مهمة */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-5 border border-white/20 hover:bg-white/15 transition-all hover:shadow-xl">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#5ba0ce] to-[#4a8bb8] flex items-center justify-center shadow-lg">
                  <HelpCircle className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white">روابط مفيدة</h3>
              </div>
              <ul className="space-y-2.5">
                <li>
                  <a
                    href="#"
                    className="text-white/90 hover:text-[#5ba0ce] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white/50 group-hover:bg-[#5ba0ce] transition-colors"></span>
                    دليل الموظف الجديد
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-white/90 hover:text-[#5ba0ce] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white/50 group-hover:bg-[#5ba0ce] transition-colors"></span>
                    الأسئلة الشائعة
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-white/90 hover:text-[#5ba0ce] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white/50 group-hover:bg-[#5ba0ce] transition-colors"></span>
                    بوابة التدريب
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-white/90 hover:text-[#5ba0ce] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white/50 group-hover:bg-[#5ba0ce] transition-colors"></span>
                    تقييم الأداء
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-white/90 hover:text-[#5ba0ce] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white/50 group-hover:bg-[#5ba0ce] transition-colors"></span>
                    بلاغات الصيانة
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/20 pt-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <p className="text-white/70 text-sm text-center md:text-right">
                جميع الحقوق محفوظة © 2025 تجمع المدينة المنورة الصحي
              </p>

              {/* Social Media Icons - Compact */}
              <div className="flex items-center gap-3">
                <span className="text-white/70 text-sm ml-2">تابعنا:</span>
                {[
                  { Icon: Twitter, color: "hover:text-[#1DA1F2]", label: "تويتر" },
                  { Icon: Instagram, color: "hover:text-[#E1306C]", label: "انستقرام" },
                  { Icon: Linkedin, color: "hover:text-[#0077B5]", label: "لينكدإن" },
                  { Icon: Youtube, color: "hover:text-[#FF0000]", label: "يوتيوب" },
                ].map(({ Icon, color, label }, idx) => (
                  <a
                    key={idx}
                    href="#"
                    className={`flex items-center justify-center w-9 h-9 rounded-lg bg-white/10 backdrop-blur ${color} transition-all hover:scale-110 hover:bg-white/20`}
                    aria-label={label}
                  >
                    <Icon className="w-4 h-4 text-white" />
                  </a>
                ))}
              </div>

              {/* Quick Links */}
              <div className="flex items-center gap-3 text-sm">
                <a href="#" className="text-white/70 hover:text-[#a8d08d] transition-colors">
                  سياسة الخصوصية
                </a>
                <span className="w-1 h-1 rounded-full bg-white/50"></span>
                <a href="#" className="text-white/70 hover:text-[#a8d08d] transition-colors">
                  الشروط والأحكام
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="h-2 bg-gradient-to-r from-[#a8d08d] via-[#1fa39b] to-[#8fc8df]"></div>
    </footer>
  )
}
