"use client"

import { Users, MessageSquare } from "lucide-react"

const departments = [
  {
    name: "التسويق والاتصال",
    members: 45,
    posts: 127,
    activity: "نشط",
    color: "#51c041",
    image: "/marketing-communication-team-meeting.jpg",
  },
  {
    name: "التطوير السياحي",
    members: 38,
    posts: 98,
    activity: "نشط جداً",
    color: "#009aac",
    image: "/tourism-development-saudi-landmarks.jpg",
  },
  {
    name: "الموارد البشرية",
    members: 22,
    posts: 156,
    activity: "نشط",
    color: "#be008d",
    image: "/human-resources-recruitment-team.jpg",
  },
  {
    name: "التقنية والمعلومات",
    members: 31,
    posts: 89,
    activity: "نشط",
    color: "#ff8300",
    image: "/it-technology-team-workspace.jpg",
  },
]

export function DepartmentSpaces() {
  return (
    <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-[#009aac]/10 flex items-center justify-center">
          <Users className="w-6 h-6 text-[#009aac]" />
        </div>
        <h2 className="text-2xl font-bold text-[#3e6e2d]">مساحات الأقسام</h2>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {departments.map((dept, index) => (
          <div
            key={index}
            className="group relative rounded-2xl overflow-hidden hover:shadow-2xl transition-all cursor-pointer"
          >
            <div className="relative h-32">
              <img
                src={dept.image || "/placeholder.svg"}
                alt={dept.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-white font-bold text-lg mb-3">{dept.name}</h3>

              
            </div>

            <div
              className="absolute top-0 left-0 w-full h-1 opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ backgroundColor: dept.color }}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
