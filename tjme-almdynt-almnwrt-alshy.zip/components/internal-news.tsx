"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const newsItems = [
  {
    title: "إطلاق مبادرة جديدة لتطوير السياحة الداخلية",
    excerpt: "أعلنت الهيئة عن إطلاق مبادرة شاملة لتعزيز السياحة الداخلية في جميع مناطق المملكة",
    image: "/saudi-tourism-internal-initiative-meeting.jpg",
    date: "منذ ساعتين",
    category: "مبادرات",
  },
  {
    title: "ورشة عمل حول خدمة العملاء المتميزة",
    excerpt: "ندعوكم للمشاركة في ورشة العمل التدريبية حول معايير خدمة العملاء",
    image: "/customer-service-training-workshop.jpg",
    date: "منذ 4 ساعات",
    category: "تدريب",
  },
  {
    title: "تكريم الموظف المثالي للربع الأول",
    excerpt: "تهانينا للموظف المثالي على الإنجازات المتميزة والتفاني في العمل",
    image: "/employee-recognition-award-ceremony.jpg",
    date: "أمس",
    category: "إنجازات",
  },
  {
    title: "افتتاح مكتب جديد في منطقة نيوم",
    excerpt: "تم افتتاح مكتب جديد للهيئة في منطقة نيوم لدعم المشاريع السياحية الكبرى",
    image: "/neom-saudi-arabia-futuristic-city-architecture.jpg",
    date: "منذ يومين",
    category: "توسع",
  },
]

const quickNews = [
  { title: "تحديث نظام الإجازات الإلكتروني", time: "منذ 3 ساعات" },
  { title: "اجتماع القيادات الشهري يوم الأحد", time: "منذ 5 ساعات" },
  { title: "فتح باب التسجيل للدورات التدريبية", time: "أمس" },
]

export function InternalNews() {
  const [currentIndex, setCurrentIndex] = useState(0)

  return (
    <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100 h-full relative overflow-hidden flex flex-col">
      <div className="absolute top-0 right-0 w-1/3 h-full opacity-10">
        <Image src="/saudi-pattern-background.png" alt="" fill className="object-cover" />
      </div>

      <div className="relative z-10 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#006ba3]">الأخبار الداخلية</h2>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentIndex((prev) => (prev - 1 + newsItems.length) % newsItems.length)}
              className="rounded-full hover:bg-[#0088cc]/10"
            >
              <ChevronRight className="w-5 h-5 text-[#006ba3]" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentIndex((prev) => (prev + 1) % newsItems.length)}
              className="rounded-full hover:bg-[#0088cc]/10"
            >
              <ChevronLeft className="w-5 h-5 text-[#006ba3]" />
            </Button>
          </div>
        </div>

        <div className="relative flex-1">
          {newsItems.map((news, index) => (
            <div
              key={index}
              className={`transition-all duration-500 ${
                index === currentIndex ? "opacity-100" : "opacity-0 absolute inset-0"
              }`}
            >
              <div className="grid grid-cols-2 gap-6">
                <div className="relative h-64 rounded-2xl overflow-hidden group">
                  <img
                    src={news.image || "/placeholder.svg"}
                    alt={news.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <span className="absolute top-4 right-4 px-3 py-1 bg-[#0088cc] text-white text-sm rounded-full">
                    {news.category}
                  </span>
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="text-2xl font-bold text-gray-800 mb-4 leading-relaxed">{news.title}</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">{news.excerpt}</p>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span>{news.date}</span>
                  </div>
                  <Button className="mt-6 bg-[#0088cc] hover:bg-[#006ba3] self-start">اقرأ المزيد</Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-sm font-semibold text-[#006ba3] mb-3">أخبار سريعة</h3>
          <div className="space-y-2">
            {quickNews.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-[#0088cc]/5 to-transparent hover:from-[#0088cc]/10 transition-all cursor-pointer group"
              >
                <span className="text-sm text-gray-700 group-hover:text-[#006ba3] transition-colors">{item.title}</span>
                <span className="text-xs text-gray-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {item.time}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
