"use client"

import type React from "react"

import { useState } from "react"
import { Clock, Users, MapPin, X, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"

// بيانات الغرف مع الحجوزات
const rooms = [
  {
    id: 1,
    name: "القاعة الرئيسية",
    capacity: 20,
    floor: "الطابق 3",
    bookings: [
      { start: 9, end: 10, title: "اجتماع الإدارة", bookedBy: "أحمد المالكي", email: "ahmed@sta.gov.sa" },
      { start: 14, end: 16, title: "ورشة عمل", bookedBy: "سارة العتيبي", email: "sara@sta.gov.sa" },
    ],
  },
  {
    id: 2,
    name: "غرفة التدريب A",
    capacity: 15,
    floor: "الطابق 2",
    bookings: [
      { start: 10, end: 12, title: "تدريب الموظفين", bookedBy: "محمد القحطاني", email: "mohammed@sta.gov.sa" },
    ],
  },
  {
    id: 3,
    name: "غرفة التدريب B",
    capacity: 12,
    floor: "الطابق 2",
    bookings: [{ start: 13, end: 15, title: "دورة تقنية", bookedBy: "نورة الشمري", email: "noura@sta.gov.sa" }],
  },
  {
    id: 4,
    name: "الغرفة الصغيرة",
    capacity: 6,
    floor: "الطابق 3",
    bookings: [{ start: 11, end: 12, title: "مقابلة توظيف", bookedBy: "فهد العنزي", email: "fahad@sta.gov.sa" }],
  },
  {
    id: 5,
    name: "قاعة المؤتمرات",
    capacity: 50,
    floor: "الطابق 1",
    bookings: [{ start: 9, end: 11, title: "المؤتمر الشهري", bookedBy: "خالد الدوسري", email: "khaled@sta.gov.sa" }],
  },
  {
    id: 6,
    name: "غرفة VIP",
    capacity: 10,
    floor: "الطابق 4",
    bookings: [{ start: 15, end: 17, title: "اجتماع الشركاء", bookedBy: "ريم الحربي", email: "reem@sta.gov.sa" }],
  },
]

// ساعات العمل من 8 صباحاً إلى 5 مساءً
const workHours = Array.from({ length: 10 }, (_, i) => i + 8)

const formatHour = (hour: number) => {
  if (hour === 12) return "12م"
  if (hour > 12) return `${hour - 12}م`
  return `${hour}ص`
}

export function MeetingRooms() {
  const [hoveredBooking, setHoveredBooking] = useState<{
    roomId: number
    booking: { start: number; end: number; title: string; bookedBy: string; email: string }
    position: { x: number; y: number }
  } | null>(null)

  const [bookingModal, setBookingModal] = useState<{
    room: (typeof rooms)[0]
    hour: number
  } | null>(null)

  const [bookingForm, setBookingForm] = useState({
    title: "",
    duration: 1,
  })

  const isHourBooked = (room: (typeof rooms)[0], hour: number) => {
    return room.bookings.find((b) => hour >= b.start && hour < b.end)
  }

  const handleMouseEnter = (
    e: React.MouseEvent,
    roomId: number,
    booking: { start: number; end: number; title: string; bookedBy: string; email: string },
  ) => {
    const rect = e.currentTarget.getBoundingClientRect()
    setHoveredBooking({
      roomId,
      booking,
      position: { x: rect.left + rect.width / 2, y: rect.top },
    })
  }

  const handleBooking = () => {
    if (bookingModal && bookingForm.title) {
      alert(`تم حجز ${bookingModal.room.name} من ${formatHour(bookingModal.hour)} لمدة ${bookingForm.duration} ساعة`)
      setBookingModal(null)
      setBookingForm({ title: "", duration: 1 })
    }
  }

  return (
    <div className="bg-gradient-to-br from-[#009aac]/5 to-white rounded-3xl p-4 md:p-6 shadow-lg border border-[#009aac]/20 h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-[#009aac]/10 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-[#009aac]" />
          </div>
          <h2 className="text-lg font-bold text-[#006d7a]">حجز غرف الاجتماعات</h2>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-gray-600">متاح</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-400"></div>
            <span className="text-gray-600">محجوز</span>
          </div>
        </div>
      </div>

      {/* Timeline Grid */}
      <div className="overflow-x-auto flex-1">
        <div className="min-w-[600px] h-full flex flex-col">
          {/* Hours Header */}
          <div className="flex items-center border-b-2 border-[#009aac]/20 pb-3 mb-3">
            <div className="w-28 flex-shrink-0 text-xs font-bold text-[#006d7a]">الغرفة</div>
            <div className="flex-1 flex gap-1">
              {workHours.map((hour) => (
                <div
                  key={hour}
                  className="flex-1 text-center text-[10px] text-gray-500 font-semibold bg-gray-50 rounded py-1"
                >
                  {formatHour(hour)}
                </div>
              ))}
            </div>
          </div>

          {/* Rooms */}
          <div className="space-y-3 flex-1">
            {rooms.map((room) => (
              <div key={room.id} className="flex items-center gap-3">
                {/* Room Info */}
                <div className="w-28 flex-shrink-0 bg-[#009aac]/5 rounded-lg p-2">
                  <h3 className="text-xs font-bold text-[#006d7a] leading-tight">{room.name}</h3>
                  <div className="flex items-center gap-2 text-[10px] text-gray-500 mt-1">
                    <span className="flex items-center gap-0.5">
                      <Users className="w-2.5 h-2.5" />
                      {room.capacity}
                    </span>
                    <span className="flex items-center gap-0.5">
                      <MapPin className="w-2.5 h-2.5" />
                      {room.floor}
                    </span>
                  </div>
                </div>

                {/* Time Slots */}
                <div className="flex-1 flex gap-1">
                  {workHours.map((hour) => {
                    const booking = isHourBooked(room, hour)
                    const isStart = booking && booking.start === hour

                    if (booking && !isStart) {
                      return null
                    }

                    if (booking && isStart) {
                      const duration = booking.end - booking.start
                      const gapCompensation = (duration - 1) * 4 // 4px = gap-1
                      return (
                        <div
                          key={hour}
                          className="h-9 bg-gradient-to-r from-red-400 to-red-500 rounded-lg cursor-pointer hover:from-red-500 hover:to-red-600 transition-all shadow-sm flex items-center justify-center relative"
                          style={{
                            flex: duration,
                            marginRight: gapCompensation > 0 ? `${gapCompensation}px` : undefined,
                          }}
                          onMouseEnter={(e) => handleMouseEnter(e, room.id, booking)}
                          onMouseLeave={() => setHoveredBooking(null)}
                        >
                          <span className="text-white text-[10px] font-medium truncate px-1">{booking.title}</span>
                        </div>
                      )
                    }

                    return (
                      <button
                        key={hour}
                        onClick={() => setBookingModal({ room, hour })}
                        className="flex-1 h-9 bg-green-100 hover:bg-green-200 border-2 border-dashed border-green-400 hover:border-green-600 rounded-lg transition-all cursor-pointer flex items-center justify-center group"
                      >
                        <span className="text-green-700 text-xs font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                          +
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Booking Tooltip */}
      {hoveredBooking && (
        <div
          className="fixed bg-white rounded-xl shadow-2xl border border-gray-200 p-3 z-[9999] w-56"
          style={{
            left: Math.min(hoveredBooking.position.x - 112, window.innerWidth - 240),
            top: hoveredBooking.position.y - 100,
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
              <Clock className="w-4 h-4 text-red-500" />
            </div>
            <div>
              <p className="font-bold text-gray-800 text-xs">{hoveredBooking.booking.title}</p>
              <p className="text-[10px] text-gray-500">
                {formatHour(hoveredBooking.booking.start)} - {formatHour(hoveredBooking.booking.end)}
              </p>
            </div>
          </div>
          <div className="border-t border-gray-100 pt-2 mt-1">
            <p className="text-[10px] text-gray-600">
              <span className="font-medium">الحاجز:</span> {hoveredBooking.booking.bookedBy}
            </p>
            <p className="text-[10px] text-gray-500">{hoveredBooking.booking.email}</p>
          </div>
        </div>
      )}

      {/* Booking Modal */}
      {bookingModal && (
        <>
          <div className="fixed inset-0 bg-black/50 z-[9998]" onClick={() => setBookingModal(null)} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-2xl p-6 z-[9999] w-[90%] max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-[#009aac]">حجز غرفة اجتماعات</h3>
              <button onClick={() => setBookingModal(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="bg-[#009aac]/10 rounded-xl p-3">
                <p className="font-bold text-[#006d7a]">{bookingModal.room.name}</p>
                <p className="text-sm text-gray-600">
                  {formatHour(bookingModal.hour)} - {bookingModal.room.floor}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">عنوان الاجتماع</label>
                <input
                  type="text"
                  value={bookingForm.title}
                  onChange={(e) => setBookingForm({ ...bookingForm, title: e.target.value })}
                  placeholder="أدخل عنوان الاجتماع"
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#009aac]/50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">المدة (بالساعات)</label>
                <select
                  value={bookingForm.duration}
                  onChange={(e) => setBookingForm({ ...bookingForm, duration: Number(e.target.value) })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#009aac]/50"
                >
                  <option value={1}>ساعة واحدة</option>
                  <option value={2}>ساعتين</option>
                  <option value={3}>3 ساعات</option>
                  <option value={4}>4 ساعات</option>
                </select>
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  onClick={handleBooking}
                  className="flex-1 bg-[#009aac] hover:bg-[#007a8a]"
                  disabled={!bookingForm.title}
                >
                  تأكيد الحجز
                </Button>
                <Button variant="outline" onClick={() => setBookingModal(null)} className="flex-1">
                  إلغاء
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
