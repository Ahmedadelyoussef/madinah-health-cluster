"use client"

import { Cloud, Sun, Sunrise, Sunset, Wind, Droplets } from "lucide-react"
import { useState, useEffect } from "react"

export function WeatherPrayer() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const prayerTimes = [
    { name: "الفجر", time: "04:45", icon: Sunrise },
    { name: "الظهر", time: "12:15", icon: Sun },
    { name: "العصر", time: "15:30", icon: Sun },
    { name: "المغرب", time: "18:05", icon: Sunset },
    { name: "العشاء", time: "19:35", icon: Cloud },
  ]

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("ar-SA", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })
  }

  const getNextPrayer = () => {
    const now = currentTime.getHours() * 60 + currentTime.getMinutes()
    for (let i = 0; i < prayerTimes.length; i++) {
      const [hour, minute] = prayerTimes[i].time.split(":").map(Number)
      const prayerMinutes = hour * 60 + minute
      if (prayerMinutes > now) {
        return i
      }
    }
    return 0
  }

  const nextPrayerIndex = getNextPrayer()

  return (
    <div className="relative bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden h-full max-h-[600px]">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/beautiful-saudi-mosque-at-sunset.jpg"
          alt="مسجد سعودي"
          className="w-full h-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-white/95 via-white/90 to-white/95"></div>
      </div>

      {/* Content Container - Flexbox layout with weather top, prayers bottom */}
      <div className="relative z-10 h-full flex flex-col">
        {/* Weather Section - Top */}
        <div className="p-5 border-b border-gray-200/50">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0088cc] to-[#006ba3] flex items-center justify-center shadow-lg">
              <Sun className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">حالة الطقس</h3>
          </div>

          <div className="flex items-center justify-between">
            {/* Current Weather */}
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-400 to-yellow-500 flex items-center justify-center shadow-xl">
                <Sun className="w-9 h-9 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">الرياض، السعودية</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold text-[#0088cc]">28°</span>
                  <span className="text-xl text-gray-400">C</span>
                </div>
                <p className="text-sm text-gray-700 font-medium mt-1">صافي جزئياً</p>
              </div>
            </div>

            {/* Weather Details */}
            <div className="flex gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Wind className="w-4 h-4 text-[#5ba0ce]" />
                  <span className="text-xs text-gray-600">الرياح</span>
                </div>
                <p className="text-lg font-bold text-gray-900">15 كم/س</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Droplets className="w-4 h-4 text-[#0088cc]" />
                  <span className="text-xs text-gray-600">الرطوبة</span>
                </div>
                <p className="text-lg font-bold text-gray-900">42%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Prayer Times Section - Bottom */}
        <div className="flex-1 p-5 overflow-y-auto relative">
          {/* Prayer Times Background Image */}
          <div className="absolute inset-0 z-0">
            <img
              src="/madinah-mosque-prophet-saudi-arabia.jpg"
              alt="المسجد النبوي"
              className="w-full h-full object-cover opacity-35"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-white/50 via-white/40 to-white/45"></div>
          </div>

          <div className="relative z-10">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1fa39b] to-[#00877f] flex items-center justify-center shadow-lg">
                  <Sunrise className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">مواقيت الصلاة</h3>
              </div>
              <div className="text-left">
                <p className="text-xs text-gray-600 mb-1">الوقت الحالي</p>
                <p className="text-base font-bold text-[#0088cc]" dir="ltr">
                  {formatTime(currentTime)}
                </p>
              </div>
            </div>

            {/* Prayer Times Grid */}
            <div className="grid grid-cols-3 gap-2 mb-3">
              {prayerTimes.map((prayer, index) => {
                const Icon = prayer.icon
                const isNext = index === nextPrayerIndex

                return (
                  <div
                    key={prayer.name}
                    className={`relative rounded-xl p-2.5 transition-all duration-300 ${
                      isNext
                        ? "bg-gradient-to-l from-[#0088cc] to-[#006ba3] shadow-lg scale-102 ring-2 ring-[#0088cc]/30"
                        : "bg-white/5 backdrop-blur-[2px] hover:bg-white/10 border border-white/20 shadow-sm"
                    }`}
                  >
                    {isNext && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#a8d08d] rounded-full flex items-center justify-center shadow-lg animate-pulse">
                        <span className="text-white text-[10px] font-bold">!</span>
                      </div>
                    )}

                    <div className="flex flex-col items-center gap-1.5">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shadow-md ${
                          isNext ? "bg-white/20" : "bg-gradient-to-br from-[#0088cc] to-[#006ba3]"
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5 text-white" />
                      </div>
                      <p
                        className={`text-sm font-bold ${isNext ? "text-white" : "text-gray-900 drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)]"}`}
                      >
                        {prayer.name}
                      </p>
                      <p
                        className={`text-base font-bold ${isNext ? "text-white" : "text-[#0088cc] drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)]"}`}
                        dir="ltr"
                      >
                        {prayer.time}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Next Prayer Indicator */}
            {nextPrayerIndex !== undefined && (
              <div className="bg-gradient-to-l from-[#0088cc]/20 to-[#1fa39b]/20 rounded-xl p-2.5 border border-[#0088cc]/30 shadow-sm">
                <div className="flex items-center justify-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#0088cc] to-[#006ba3] flex items-center justify-center animate-pulse">
                    <Sunrise className="w-3.5 h-3.5 text-white" />
                  </div>
                  <p className="text-xs font-bold text-gray-900">
                    الصلاة القادمة: <span className="text-[#0088cc]">{prayerTimes[nextPrayerIndex].name}</span>
                    {" في "}
                    <span className="text-[#1fa39b]" dir="ltr">
                      {prayerTimes[nextPrayerIndex].time}
                    </span>
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
