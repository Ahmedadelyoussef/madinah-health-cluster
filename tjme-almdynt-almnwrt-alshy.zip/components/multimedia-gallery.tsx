"use client"

import { useState } from "react"
import { Play, ImageIcon, FileVideo, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const mediaItems = [
  {
    type: "image",
    url: "/images/hospital-opening.jpg",
    title: "افتتاح مركز القلب الجديد",
    date: "منذ يومين",
  },
  {
    type: "video",
    url: "/images/medical-team-training.jpg",
    title: "فيديو: تدريب الفرق الطبية",
    date: "منذ 3 أيام",
  },
  {
    type: "image",
    url: "/images/emergency-services.jpg",
    title: "خدمات الطوارئ المتطورة",
    date: "منذ 5 أيام",
  },
  {
    type: "video",
    url: "/images/telemedicine-services.jpg",
    title: "خدمات الرعاية الصحية عن بعد",
    date: "منذ أسبوع",
  },
  {
    type: "image",
    url: "/images/vaccination-campaign.jpg",
    title: "حملة التطعيم الوطنية",
    date: "منذ أسبوعين",
  },
  {
    type: "image",
    url: "/images/health-awareness.jpg",
    title: "برنامج التوعية الصحية",
    date: "منذ أسبوعين",
  },
]

export function MultimediaGallery() {
  const [startIndex, setStartIndex] = useState(0)
  const itemsToShow = 4

  const nextSlide = () => {
    setStartIndex((prev) => (prev + 1) % (mediaItems.length - itemsToShow + 1))
  }

  const prevSlide = () => {
    setStartIndex((prev) => (prev - 1 + mediaItems.length - itemsToShow + 1) % (mediaItems.length - itemsToShow + 1))
  }

  return (
    <div className="bg-gradient-to-br from-[#0088cc]/5 to-white rounded-3xl p-8 shadow-lg border border-[#0088cc]/20 relative overflow-hidden">
      {/* Pattern background */}
      <div
        className="absolute top-0 right-0 w-64 h-64 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0L60 30L30 60L0 30z' fill='%230088cc'/%3E%3C/svg%3E")`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#0088cc]/10 flex items-center justify-center">
              <ImageIcon className="w-6 h-6 text-[#0088cc]" />
            </div>
            <h2 className="text-2xl font-bold text-[#006ba3]">معرض الوسائط</h2>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={prevSlide}
              className="rounded-full border-[#0088cc]/20 hover:bg-[#0088cc]/10 bg-transparent"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={nextSlide}
              className="rounded-full border-[#0088cc]/20 hover:bg-[#0088cc]/10 bg-transparent"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4">
          {mediaItems.slice(startIndex, startIndex + itemsToShow).map((item, index) => (
            <div
              key={index}
              className="group relative aspect-video rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all cursor-pointer"
            >
              <img
                src={item.url || "/placeholder.svg"}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              {item.type === "video" && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Play className="w-8 h-8 text-white fill-white" />
                  </div>
                </div>
              )}

              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-white font-bold text-sm mb-1">{item.title}</h3>
                <p className="text-white/80 text-xs">{item.date}</p>
              </div>

              <div className="absolute top-3 right-3">
                {item.type === "video" ? (
                  <FileVideo className="w-5 h-5 text-white" />
                ) : (
                  <ImageIcon className="w-5 h-5 text-white" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
