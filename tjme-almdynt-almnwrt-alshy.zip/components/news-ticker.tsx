"use client"

import { Newspaper, AlertCircle, TrendingUp, Award, Calendar, Zap } from "lucide-react"

const newsItems = [
  {
    icon: AlertCircle,
    text: "تذكير: آخر موعد لتقديم طلبات الإجازة السنوية نهاية الشهر الجاري",
    color: "text-red-400",
    urgent: true, // إضافة خاصية urgent للأخبار المهمة
  },
  {
    icon: Award,
    text: "مبروك للفريق التسويقي على الفوز بجائزة التميز لهذا الربع",
    color: "text-amber-400",
  },
  {
    icon: Calendar,
    text: "اجتماع الجمعية العمومية القادم يوم الأربعاء الساعة 10 صباحاً",
    color: "text-blue-400",
  },
  {
    icon: TrendingUp,
    text: "ارتفاع معدل رضا الموظفين بنسبة 15% هذا العام",
    color: "text-green-400",
    urgent: true, // خبر مهم آخر
  },
  {
    icon: Newspaper,
    text: "ورشة عمل حول التطوير المهني يوم الخميس - التسجيل متاح الآن",
    color: "text-cyan-400",
  },
]

export function NewsTicker() {
  const repeatedNews = Array(10).fill(newsItems).flat()

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-gradient-to-r from-[#0088cc] via-[#006ba3] to-[#0088cc] text-white py-3 shadow-2xl border-t-2 border-white/20">
      <div className="overflow-hidden whitespace-nowrap">
        <div className="flex animate-scroll-continuous">
          {repeatedNews.map((item, index) => {
            const Icon = item.icon
            const isUrgent = item.urgent

            return (
              <span
                key={index}
                className={`inline-flex items-center gap-2 mx-8 flex-shrink-0 ${isUrgent ? "animate-pulse-slow" : ""}`}
              >
                {isUrgent && (
                  <span className="relative">
                    <span className="absolute -inset-1 bg-red-500 opacity-75 blur-sm animate-ping"></span>
                    <span className="relative inline-flex items-center gap-1 bg-red-500 text-white px-2 py-0.5 rounded-full text-xs font-bold animate-bounce-subtle">
                      <Zap className="w-3 h-3" />
                      عاجل
                    </span>
                  </span>
                )}

                <span className={`${isUrgent ? "animate-glow" : ""}`}>
                  <Icon className={`w-5 h-5 ${item.color} flex-shrink-0 ${isUrgent ? "drop-shadow-glow" : ""}`} />
                </span>

                <span
                  className={`text-base font-medium whitespace-nowrap ${isUrgent ? "font-bold text-yellow-200" : ""}`}
                >
                  {item.text}
                </span>
                <span className="text-white/40 mx-3">•</span>
              </span>
            )
          })}
        </div>
      </div>
    </div>
  )
}
