"use client"

import { useState } from "react"
import { CheckSquare, Square, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Todo {
  id: number
  text: string
  completed: boolean
  priority: "high" | "medium" | "low"
}

const initialTodos: Todo[] = [
  { id: 1, text: "مراجعة تقرير الربع الأول", completed: false, priority: "high" },
  { id: 2, text: "حضور اجتماع الفريق", completed: true, priority: "medium" },
  { id: 3, text: "إرسال البريد للإدارة", completed: false, priority: "high" },
  { id: 4, text: "تحديث البيانات", completed: false, priority: "low" },
]

const priorityColors = {
  high: "#ff424c",
  medium: "#ff8300",
  low: "#51c041",
}

export function TodoList() {
  const [todos, setTodos] = useState(initialTodos)
  const [newTodo, setNewTodo] = useState("")

  const toggleTodo = (id: number) => {
    setTodos(todos.map((todo) => (todo.id === id ? { ...todo, completed: !todo.completed } : todo)))
  }

  const deleteTodo = (id: number) => {
    setTodos(todos.filter((todo) => todo.id !== id))
  }

  const addTodo = () => {
    if (newTodo.trim()) {
      setTodos([
        ...todos,
        {
          id: Date.now(),
          text: newTodo,
          completed: false,
          priority: "medium",
        },
      ])
      setNewTodo("")
    }
  }

  return (
    <div className="bg-gradient-to-br from-[#ff8300]/5 to-white rounded-3xl p-6 shadow-lg border border-[#ff8300]/20 h-full">
      <h2 className="text-xl font-bold text-[#3e6e2d] mb-6">قائمة المهام</h2>

      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && addTodo()}
          placeholder="أضف مهمة جديدة..."
          className="flex-1 px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#ff8300]"
        />
        <Button onClick={addTodo} size="icon" className="bg-[#ff8300] hover:bg-[#ff5600] rounded-xl">
          <Plus className="w-5 h-5" />
        </Button>
      </div>

      <div className="space-y-2 max-h-80 overflow-y-auto">
        {todos.map((todo) => (
          <div
            key={todo.id}
            className="group flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:shadow-md transition-all"
          >
            <button onClick={() => toggleTodo(todo.id)} className="flex-shrink-0">
              {todo.completed ? (
                <CheckSquare className="w-5 h-5 text-green-500" />
              ) : (
                <Square className="w-5 h-5 text-gray-400" />
              )}
            </button>

            <div className="w-1 h-8 rounded-full" style={{ backgroundColor: priorityColors[todo.priority] }} />

            <span className={`flex-1 text-sm ${todo.completed ? "line-through text-gray-400" : "text-gray-700"}`}>
              {todo.text}
            </span>

            <button
              onClick={() => deleteTodo(todo.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Trash2 className="w-4 h-4 text-red-400 hover:text-red-600" />
            </button>
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between text-xs text-gray-500">
        <span>{todos.filter((t) => !t.completed).length} مهمة متبقية</span>
        <span>{todos.filter((t) => t.completed).length} مكتملة</span>
      </div>
    </div>
  )
}
