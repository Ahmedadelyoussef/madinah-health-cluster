"use client"

import { Mail, Phone, Building2, User, Users, Linkedin } from "lucide-react"
import Image from "next/image"
import { useState } from "react"

export function ProfileHeader() {
  const [hoveredMember, setHoveredMember] = useState<number | null>(null)

  const teamMembers = [
    {
      id: 1,
      src: "/saudi-team-member-1.jpg",
      name: "خالد السعيد",
      phone: "+966 55 234 5678",
      email: "khaled.alsaeed@sta.gov.sa",
    },
    {
      id: 2,
      src: "/saudi-team-member-2.jpg",
      name: "نورة الدوسري",
      phone: "+966 50 345 6789",
      email: "nora.aldosari@sta.gov.sa",
    },
    {
      id: 3,
      src: "/saudi-team-member-3.jpg",
      name: "سلطان العمري",
      phone: "+966 54 456 7890",
      email: "sultan.alomari@sta.gov.sa",
    },
    {
      id: 4,
      src: "/saudi-team-member-4.jpg",
      name: "ريم الشمري",
      phone: "+966 56 567 8901",
      email: "reem.alshamri@sta.gov.sa",
    },
    {
      id: 5,
      src: "/saudi-team-member-5.jpg",
      name: "محمد القحطاني",
      phone: "+966 58 678 9012",
      email: "mohammed.alqahtani@sta.gov.sa",
    },
    {
      id: 6,
      src: "/saudi-team-member-6.jpg",
      name: "سارة الغامدي",
      phone: "+966 53 789 0123",
      email: "sarah.alghamdi@sta.gov.sa",
    },
    {
      id: 7,
      src: "/saudi-team-member-7.jpg",
      name: "عبدالله الزهراني",
      phone: "+966 55 890 1234",
      email: "abdullah.alzahrani@sta.gov.sa",
    },
    {
      id: 8,
      src: "/saudi-team-member-8.jpg",
      name: "منى العتيبي",
      phone: "+966 50 901 2345",
      email: "mona.alotaibi@sta.gov.sa",
    },
  ]

  return (
    <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
      {/* Cover Image */}
      <div className="h-48 bg-gradient-to-r from-[#0088cc] via-[#006ba3] to-[#1fa39b] relative overflow-hidden">
        <Image src="/saudi-patterns-strip.jpg" alt="نمط" fill className="object-cover opacity-20" />
      </div>

      {/* Profile Info */}
      <div className="px-8 pb-8">
        {/* Avatar */}
        <div className="flex items-end justify-between -mt-20">
          <div className="relative">
            <div className="w-40 h-40 rounded-3xl overflow-hidden border-4 border-white shadow-xl">
              <Image
                src="/saudi-man-traditional-thobe-professional.jpg"
                alt="أحمد المالكي"
                width={160}
                height={160}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute bottom-2 right-2 w-6 h-6 bg-green-500 border-4 border-white rounded-full"></div>
            {/* LinkedIn Icon */}
            <a
              href="https://www.linkedin.com/in/ahmed-almalki"
              target="_blank"
              rel="noopener noreferrer"
              className="absolute -left-2 bottom-2 w-9 h-9 bg-[#0077b5] rounded-full flex items-center justify-center shadow-lg hover:scale-110 hover:shadow-xl transition-all border-2 border-white"
              title="الملف الشخصي على LinkedIn"
            >
              <Linkedin className="w-5 h-5 text-white" />
            </a>
          </div>

          <div className="flex gap-2 mb-4">
            <button className="px-6 py-2.5 bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white rounded-xl font-semibold hover:shadow-lg transition-all">
              تعديل الملف الشخصي
            </button>
          </div>
        </div>

        {/* Name and Title */}
        <div className="mt-6">
          <h1 className="text-3xl font-bold text-gray-900">أحمد محمد المالكي</h1>
          <p className="text-lg text-[#0088cc] font-semibold mt-1">مدير التسويق والاتصال</p>
        </div>

        {/* Contact Info Grid */}
        <div className="grid grid-cols-4 gap-4 mt-6">
          <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-[#0088cc]/10 flex items-center justify-center">
              <Mail className="w-5 h-5 text-[#0088cc]" />
            </div>
            <div>
              <p className="text-xs text-gray-500">البريد الإلكتروني</p>
              <p className="font-semibold text-sm">ahmed.almalki@sta.gov.sa</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-[#1fa39b]/10 flex items-center justify-center">
              <Phone className="w-5 h-5 text-[#1fa39b]" />
            </div>
            <div>
              <p className="text-xs text-gray-500">رقم الجوال</p>
              <p className="font-semibold text-sm" dir="ltr">
                +966 50 123 4567
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-[#5ba0ce]/10 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-[#5ba0ce]" />
            </div>
            <div>
              <p className="text-xs text-gray-500">الإدارة</p>
              <p className="font-semibold text-sm">التسويق والاتصال</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-[#a8d08d]/10 flex items-center justify-center">
              <User className="w-5 h-5 text-[#a8d08d]" />
            </div>
            <div>
              <p className="text-xs text-gray-500">المدير المباشر</p>
              <p className="font-semibold text-sm">فهد العتيبي</p>
            </div>
          </div>
        </div>

        {/* Team Members */}
        <div className="mt-6 p-6 bg-gradient-to-br from-[#0088cc]/5 to-[#1fa39b]/5 rounded-2xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-[#0088cc]" />
              فريق العمل
            </h3>
            <span className="text-sm text-gray-500">8 موظفين</span>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {teamMembers.map((member) => (
              <div
                key={member.id}
                className="relative"
                onMouseEnter={() => setHoveredMember(member.id)}
                onMouseLeave={() => setHoveredMember(null)}
              >
                <div className="w-14 h-14 rounded-full overflow-hidden border-3 border-white shadow-lg hover:scale-110 hover:shadow-xl transition-all cursor-pointer ring-2 ring-[#0088cc]/20 hover:ring-[#0088cc]/50">
                  <Image
                    src={member.src || "/placeholder.svg"}
                    alt={member.name}
                    width={56}
                    height={56}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Tooltip */}
                {hoveredMember === member.id && (
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 bg-white rounded-xl shadow-2xl border border-gray-200 p-4 z-50 animate-in fade-in slide-in-from-bottom-2">
                    {/* Arrow */}
                    <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-2">
                      <div className="w-4 h-4 bg-white border-r border-b border-gray-200 transform rotate-45"></div>
                    </div>

                    {/* Content */}
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#0088cc]">
                          <Image
                            src={member.src || "/placeholder.svg"}
                            alt={member.name}
                            width={48}
                            height={48}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900">{member.name}</h4>
                          <p className="text-xs text-gray-500">عضو فريق</p>
                        </div>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-gray-100">
                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-7 h-7 rounded-lg bg-[#1fa39b]/10 flex items-center justify-center flex-shrink-0">
                            <Phone className="w-3.5 h-3.5 text-[#1fa39b]" />
                          </div>
                          <span className="text-gray-700" dir="ltr">
                            {member.phone}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-7 h-7 rounded-lg bg-[#0088cc]/10 flex items-center justify-center flex-shrink-0">
                            <Mail className="w-3.5 h-3.5 text-[#0088cc]" />
                          </div>
                          <span className="text-gray-700 truncate">{member.email}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
