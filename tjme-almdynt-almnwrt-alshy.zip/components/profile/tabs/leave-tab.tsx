"use client"

import { Calendar, Plus } from "lucide-react"

export function LeaveTab() {
  const leaveBalance = [
    { type: "إجازة سنوية", total: 30, used: 12, remaining: 18, color: "bg-[#0088cc]" },
    { type: "إجازة مرضية", total: 15, used: 3, remaining: 12, color: "bg-[#1fa39b]" },
    { type: "إجازة طارئة", total: 5, used: 1, remaining: 4, color: "bg-[#5ba0ce]" },
  ]

  const upcomingLeave = [
    { type: "إجازة سنوية", startDate: "2024-02-15", endDate: "2024-02-20", days: 5, status: "معتمدة" },
    { type: "إجازة مرضية", startDate: "2024-01-22", endDate: "2024-01-23", days: 2, status: "قيد المراجعة" },
  ]

  const leaveHistory = [
    { type: "إجازة سنوية", startDate: "2024-01-01", endDate: "2024-01-05", days: 5, status: "مكتملة" },
    { type: "إجازة طارئة", startDate: "2023-12-15", endDate: "2023-12-15", days: 1, status: "مكتملة" },
    { type: "إجازة مرضية", startDate: "2023-11-20", endDate: "2023-11-21", days: 2, status: "مكتملة" },
  ]

  return (
    <div className="space-y-6">
      {/* New Leave Request Button */}
      <button className="w-full bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-3">
        <Plus className="w-6 h-6" />
        <span className="text-lg font-bold">طلب إجازة جديدة</span>
      </button>

      {/* Leave Balance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {leaveBalance.map((leave, index) => (
          <div key={index} className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
            <h4 className="text-lg font-bold text-gray-800 mb-4">{leave.type}</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">المجموع</span>
                <span className="font-semibold text-gray-800">{leave.total} يوم</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">المستخدم</span>
                <span className="font-semibold text-gray-800">{leave.used} يوم</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">المتبقي</span>
                <span className={`font-bold text-lg ${leave.color.replace("bg-", "text-")}`}>
                  {leave.remaining} يوم
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div
                  className={`${leave.color} h-2 rounded-full transition-all`}
                  style={{ width: `${(leave.remaining / leave.total) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Upcoming Leave */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
        <h3 className="text-xl font-bold text-[#0088cc] mb-4">الإجازات القادمة</h3>
        <div className="space-y-3">
          {upcomingLeave.map((leave, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-gradient-to-r from-[#0088cc]/5 to-[#006ba3]/5 rounded-xl"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0088cc] to-[#006ba3] flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">{leave.type}</p>
                  <p className="text-sm text-gray-500">
                    {leave.startDate} - {leave.endDate} ({leave.days} أيام)
                  </p>
                </div>
              </div>
              <span className="px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-medium">
                {leave.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Leave History */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
        <h3 className="text-xl font-bold text-[#0088cc] mb-4">سجل الإجازات</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">النوع</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">تاريخ البداية</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">تاريخ النهاية</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">عدد الأيام</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {leaveHistory.map((leave, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm text-gray-800">{leave.type}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{leave.startDate}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{leave.endDate}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{leave.days}</td>
                  <td className="px-4 py-3">
                    <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">
                      {leave.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
