"use client"

export function RequestsTab() {
  const requests = [
    {
      id: "REQ-2024-001",
      type: "طلب إجازة سنوية",
      date: "2024-01-15",
      status: "قيد المراجعة",
      statusColor: "bg-yellow-500",
    },
    { id: "REQ-2024-002", type: "شهادة راتب", date: "2024-01-14", status: "مكتمل", statusColor: "bg-green-500" },
    {
      id: "REQ-2024-003",
      type: "طلب دورة تدريبية",
      date: "2024-01-12",
      status: "قيد المراجعة",
      statusColor: "bg-yellow-500",
    },
    { id: "REQ-2024-004", type: "تعديل وقت الحضور", date: "2024-01-10", status: "مكتمل", statusColor: "bg-green-500" },
    { id: "REQ-2024-005", type: "طلب سلفة", date: "2024-01-08", status: "مرفوض", statusColor: "bg-red-500" },
    { id: "REQ-2024-006", type: "شهادة عمل", date: "2024-01-05", status: "مكتمل", statusColor: "bg-green-500" },
    {
      id: "REQ-2024-007",
      type: "تحديث بيانات",
      date: "2024-01-03",
      status: "قيد المعالجة",
      statusColor: "bg-blue-500",
    },
    {
      id: "REQ-2024-008",
      type: "طلب جهاز كمبيوتر",
      date: "2024-01-01",
      status: "قيد المعالجة",
      statusColor: "bg-blue-500",
    },
  ]

  const statusStats = [
    { label: "قيد المراجعة", count: 2, color: "bg-yellow-500" },
    { label: "قيد المعالجة", count: 2, color: "bg-blue-500" },
    { label: "مكتمل", count: 3, color: "bg-green-500" },
    { label: "مرفوض", count: 1, color: "bg-red-500" },
  ]

  return (
    <div className="space-y-6">
      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {statusStats.map((stat, index) => (
          <div key={index} className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-gray-800">{stat.count}</p>
                <p className="text-sm text-gray-500">{stat.label}</p>
              </div>
              <div className={`w-3 h-12 ${stat.color} rounded-full`}></div>
            </div>
          </div>
        ))}
      </div>

      {/* Requests Table */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <h3 className="text-xl font-bold text-[#0088cc]">جميع الطلبات</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">رقم الطلب</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">نوع الطلب</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">التاريخ</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">الحالة</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {requests.map((request, index) => (
                <tr key={index} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">{request.id}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{request.type}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{request.date}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium text-white ${request.statusColor}`}
                    >
                      {request.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-[#0088cc] hover:text-[#006ba3] text-sm font-medium">عرض التفاصيل</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
