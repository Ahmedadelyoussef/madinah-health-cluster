"use client"

import type React from "react"

import {
  Search,
  Calendar,
  DollarSign,
  Monitor,
  GraduationCap,
  Users,
  Briefcase,
  HelpCircle,
  FileText,
  CreditCard,
  Home,
  Plane,
  Award as IdCard,
  UserPlus,
  Building,
  Clock,
  Coffee,
  Wifi,
  Phone,
  Shield,
  Award,
  BookOpen,
  Globe,
  Laptop,
  Printer,
  Network,
  Mail,
  Key,
  Settings,
  Ambulance,
  Baby,
  HeartHandshake,
  MapPin,
  TrendingUp,
  PiggyBank,
  Receipt,
  Gift,
  ChevronLeft,
  X,
  Upload,
  Send,
  CalendarDays,
} from "lucide-react"
import { useState } from "react"

interface SelectedService {
  name: string
  icon: any
  category: string
  color: string
}

export function ServicesTab() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedService, setSelectedService] = useState<SelectedService | null>(null)
  const [formData, setFormData] = useState({
    reason: "",
    startDate: "",
    endDate: "",
    notes: "",
    attachment: null as File | null,
  })

  const handleServiceClick = (service: any, category: any) => {
    setSelectedService({
      name: service.name,
      icon: service.icon,
      category: category.title,
      color: category.color,
    })
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setSelectedService(null)
    setFormData({
      reason: "",
      startDate: "",
      endDate: "",
      notes: "",
      attachment: null,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Service Request Submitted:", {
      service: selectedService?.name,
      ...formData,
    })
    // Here would be the API call to submit the request
    handleCloseModal()
  }

  const serviceCategories = [
    {
      title: "خدمات الموارد البشرية",
      icon: Users,
      color: "from-[#0088cc] to-[#006ba3]",
      services: [
        { name: "شهادة راتب", icon: FileText },
        { name: "شهادة عمل", icon: Award },
        { name: "تحديث البيانات الشخصية", icon: Settings },
        { name: "طلب بدل سكن", icon: Home },
        { name: "طلب بدل نقل", icon: MapPin },
        { name: "طلب تعريف بالراتب للبنك", icon: Building },
        { name: "طلب خطاب للسفارة", icon: Globe },
        { name: "تجديد الهوية", icon: IdCard },
        { name: "إضافة المعالين", icon: UserPlus },
        { name: "طلب كشف حساب بنكي", icon: CreditCard },
      ],
    },
    {
      title: "الإجازات والغياب",
      icon: Calendar,
      color: "from-[#1fa39b] to-[#0d8a84]",
      services: [
        { name: "طلب إجازة سنوية", icon: Calendar },
        { name: "طلب إجازة مرضية", icon: Ambulance },
        { name: "طلب إجازة طارئة", icon: Shield },
        { name: "تمديد إجازة", icon: Clock },
        { name: "إلغاء إجازة", icon: FileText },
        { name: "إجازة بدون راتب", icon: Coffee },
        { name: "إجازة أمومة", icon: Baby },
        { name: "إجازة أبوة", icon: HeartHandshake },
        { name: "إجازة حج", icon: MapPin },
        { name: "إجازة عمرة", icon: MapPin },
      ],
    },
    {
      title: "الحضور والانصراف",
      icon: Briefcase,
      color: "from-[#a8d08d] to-[#8bb870]",
      services: [
        { name: "طلب تعديل وقت الحضور", icon: Clock },
        { name: "طلب تعديل وقت الانصراف", icon: Clock },
        { name: "طلب استئذان", icon: FileText },
        { name: "عمل إضافي", icon: TrendingUp },
        { name: "العمل من المنزل", icon: Home },
        { name: "طلب إجازة ساعات", icon: Clock },
        { name: "تقرير الحضور الشهري", icon: FileText },
        { name: "نسيان البصمة", icon: IdCard },
      ],
    },
    {
      title: "المالية والمطالبات",
      icon: DollarSign,
      color: "from-[#5ba0ce] to-[#4189b3]",
      services: [
        { name: "طلب سلفة", icon: DollarSign },
        { name: "مطالبة مالية", icon: Receipt },
        { name: "بدل سفر", icon: Plane },
        { name: "بدل ضيافة", icon: Coffee },
        { name: "استرجاع مصاريف", icon: CreditCard },
        { name: "طلب قرض", icon: PiggyBank },
        { name: "بدل هاتف", icon: Phone },
        { name: "بدل إنترنت", icon: Wifi },
        { name: "مكافأة أداء", icon: Gift },
        { name: "علاوة سنوية", icon: TrendingUp },
      ],
    },
    {
      title: "التطوير والتدريب",
      icon: GraduationCap,
      color: "from-[#8fc8df] to-[#6ba9c4]",
      services: [
        { name: "طلب دورة تدريبية", icon: BookOpen },
        { name: "طلب شهادة مهنية", icon: Award },
        { name: "برنامج تطوير", icon: TrendingUp },
        { name: "ورشة عمل", icon: Users },
        { name: "مؤتمر خارجي", icon: Globe },
        { name: "دورة لغة", icon: BookOpen },
        { name: "دبلوم احترافي", icon: GraduationCap },
        { name: "ماجستير تنفيذي", icon: GraduationCap },
      ],
    },
    {
      title: "التقنية والدعم",
      icon: Monitor,
      color: "from-[#006ba3] to-[#0088cc]",
      services: [
        { name: "طلب جهاز كمبيوتر", icon: Laptop },
        { name: "طلب صلاحيات نظام", icon: Key },
        { name: "دعم تقني", icon: Settings },
        { name: "إعادة تعيين كلمة المرور", icon: Shield },
        { name: "طلب برنامج", icon: Monitor },
        { name: "طلب طابعة", icon: Printer },
        { name: "مشكلة شبكة", icon: Network },
        { name: "طلب بريد إلكتروني إضافي", icon: Mail },
        { name: "طلب خط هاتف", icon: Phone },
        { name: "طلب وصول VPN", icon: Shield },
      ],
    },
  ]

  const filteredCategories = serviceCategories
    .map((category) => ({
      ...category,
      services: category.services.filter((service) => service.name.toLowerCase().includes(searchQuery.toLowerCase())),
    }))
    .filter((category) => category.services.length > 0)

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="ابحث عن خدمة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-12 pl-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc] text-right"
          />
        </div>
      </div>

      {/* Service Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredCategories.map((category, index) => {
          const Icon = category.icon
          return (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 hover:shadow-xl transition-all"
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center`}
                >
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-800">{category.title}</h3>
              </div>
              {/* Improved service display with icons */}
              <div className="space-y-2">
                {category.services.map((service, idx) => {
                  const ServiceIcon = service.icon
                  return (
                    <button
                      key={idx}
                      onClick={() => handleServiceClick(service, category)}
                      className="w-full flex items-center justify-between gap-3 text-sm text-right p-3 bg-gray-50 rounded-xl hover:bg-gradient-to-r hover:from-[#0088cc]/10 hover:to-[#006ba3]/10 hover:text-[#0088cc] hover:shadow-md transition-all group"
                    >
                      <ChevronLeft className="w-4 h-4 text-gray-400 group-hover:text-[#0088cc] transition-colors" />
                      <span className="flex-1 font-medium">{service.name}</span>
                      <div
                        className={`w-8 h-8 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm`}
                      >
                        <ServiceIcon className="w-4 h-4 text-white" />
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>

      {searchQuery && filteredCategories.length === 0 && (
        <div className="text-center py-12">
          <HelpCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">لم يتم العثور على خدمات مطابقة</p>
        </div>
      )}

      {isModalOpen && selectedService && (
        <div className="fixed inset-0 z-[10000] flex items-center justify-center">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={handleCloseModal}></div>

          {/* Modal */}
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className={`bg-gradient-to-r ${selectedService.color} p-6 rounded-t-3xl relative`}>
              <button
                onClick={handleCloseModal}
                className="absolute left-4 top-4 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-all"
              >
                <X className="w-5 h-5 text-white" />
              </button>

              <div className="flex items-center gap-4 pr-12">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                  {selectedService.icon && <selectedService.icon className="w-8 h-8 text-white" />}
                </div>
                <div className="text-white">
                  <h2 className="text-2xl font-bold mb-1">{selectedService.name}</h2>
                  <p className="text-white/80 text-sm">{selectedService.category}</p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Reason/Purpose */}
              <div>
                <label className="block text-right text-gray-700 font-semibold mb-2">سبب الطلب *</label>
                <textarea
                  required
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="اكتب سبب طلب الخدمة..."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc] text-right resize-none"
                />
              </div>

              {/* Date Range */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-right text-gray-700 font-semibold mb-2">تاريخ البداية *</label>
                  <div className="relative">
                    <CalendarDays className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="date"
                      required
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                      className="w-full px-4 py-3 pl-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc] text-right"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-right text-gray-700 font-semibold mb-2">تاريخ النهاية</label>
                  <div className="relative">
                    <CalendarDays className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                      className="w-full px-4 py-3 pl-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc] text-right"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Notes */}
              <div>
                <label className="block text-right text-gray-700 font-semibold mb-2">ملاحظات إضافية</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="أي تفاصيل أو ملاحظات إضافية..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc] text-right resize-none"
                />
              </div>

              {/* File Attachment */}
              <div>
                <label className="block text-right text-gray-700 font-semibold mb-2">إرفاق مستند</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-[#0088cc] transition-colors">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <input
                    type="file"
                    onChange={(e) => setFormData({ ...formData, attachment: e.target.files?.[0] || null })}
                    className="hidden"
                    id="file-upload"
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer text-[#0088cc] hover:text-[#006ba3] font-medium"
                  >
                    اضغط لاختيار ملف
                  </label>
                  <p className="text-xs text-gray-500 mt-2">PDF, DOC, DOCX, JPG, PNG (الحد الأقصى 5 ميجابايت)</p>
                  {formData.attachment && (
                    <p className="text-sm text-green-600 mt-2">✓ تم اختيار: {formData.attachment.name}</p>
                  )}
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="flex-1 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl transition-all"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className={`flex-1 px-6 py-3 bg-gradient-to-r ${selectedService.color} text-white font-bold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2`}
                >
                  <Send className="w-5 h-5" />
                  إرسال الطلب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
