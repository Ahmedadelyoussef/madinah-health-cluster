"use client"

import { Clock, CheckCircle, Calendar, TrendingUp } from "lucide-react"

export function AttendanceTab() {
  const todayAttendance = {
    checkIn: "08:15 ص",
    checkOut: "--:-- --",
    workHours: "7:45",
    status: "في العمل",
  }

  const attendanceHistory = [
    { date: "2024-01-15", checkIn: "08:20 ص", checkOut: "05:00 م", hours: "8:40", status: "حاضر" },
    { date: "2024-01-14", checkIn: "08:15 ص", checkOut: "05:05 م", hours: "8:50", status: "حاضر" },
    { date: "2024-01-13", checkIn: "08:30 ص", checkOut: "05:15 م", hours: "8:45", status: "حاضر" },
    { date: "2024-01-12", checkIn: "08:10 ص", checkOut: "05:00 م", hours: "8:50", status: "حاضر" },
    { date: "2024-01-11", checkIn: "08:25 ص", checkOut: "05:10 م", hours: "8:45", status: "حاضر" },
    { date: "2024-01-10", checkIn: "--", checkOut: "--", hours: "0:00", status: "إجازة" },
    { date: "2024-01-09", checkIn: "08:15 ص", checkOut: "05:00 م", hours: "8:45", status: "حاضر" },
    { date: "2024-01-08", checkIn: "08:20 ص", checkOut: "05:05 م", hours: "8:45", status: "حاضر" },
  ]

  const monthlyStats = {
    workDays: 20,
    presentDays: 18,
    absences: 0,
    leaves: 2,
    lateArrivals: 3,
    earlyDepartures: 1,
    overtime: "5:30",
  }

  return (
    <div className="space-y-6">
      {/* Today's Attendance */}
      <div className="bg-gradient-to-br from-[#0088cc] to-[#006ba3] rounded-2xl p-8 text-white shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold">حضور اليوم</h3>
          <Clock className="w-10 h-10" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <p className="text-sm opacity-90 mb-1">وقت الحضور</p>
            <p className="text-2xl font-bold">{todayAttendance.checkIn}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <p className="text-sm opacity-90 mb-1">وقت الانصراف</p>
            <p className="text-2xl font-bold">{todayAttendance.checkOut}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <p className="text-sm opacity-90 mb-1">ساعات العمل</p>
            <p className="text-2xl font-bold">{todayAttendance.workHours}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <p className="text-sm opacity-90 mb-1">الحالة</p>
            <p className="text-2xl font-bold">{todayAttendance.status}</p>
          </div>
        </div>
      </div>

      {/* Monthly Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle className="w-8 h-8 text-green-500" />
            <span className="text-3xl font-bold text-gray-800">{monthlyStats.presentDays}</span>
          </div>
          <p className="text-sm text-gray-500">أيام الحضور</p>
        </div>

        <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="w-8 h-8 text-[#1fa39b]" />
            <span className="text-3xl font-bold text-gray-800">{monthlyStats.leaves}</span>
          </div>
          <p className="text-sm text-gray-500">أيام الإجازة</p>
        </div>

        <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="w-8 h-8 text-[#5ba0ce]" />
            <span className="text-3xl font-bold text-gray-800">{monthlyStats.lateArrivals}</span>
          </div>
          <p className="text-sm text-gray-500">تأخيرات</p>
        </div>

        <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-8 h-8 text-[#0088cc]" />
            <span className="text-3xl font-bold text-gray-800">{monthlyStats.overtime}</span>
          </div>
          <p className="text-sm text-gray-500">ساعات إضافية</p>
        </div>
      </div>

      {/* Attendance History */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
        <h3 className="text-xl font-bold text-[#0088cc] mb-4">سجل الحضور</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">التاريخ</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">وقت الحضور</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">وقت الانصراف</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">ساعات العمل</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {attendanceHistory.map((record, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{record.date}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{record.checkIn}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{record.checkOut}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{record.hours}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        record.status === "حاضر" ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {record.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
