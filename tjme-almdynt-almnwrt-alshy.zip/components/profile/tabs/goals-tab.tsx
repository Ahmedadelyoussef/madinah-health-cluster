"use client"

import { Target, TrendingUp, Award, Calendar } from "lucide-react"

export function GoalsTab() {
  const goals = [
    {
      title: "تطوير مهارات القيادة",
      description: "إكمال برنامج تطوير القيادة وتطبيق المهارات المكتسبة",
      progress: 75,
      deadline: "2024-06-30",
      status: "قيد التنفيذ",
      color: "from-[#0088cc] to-[#006ba3]",
    },
    {
      title: "تحسين مؤشرات الأداء",
      description: "زيادة معدل الإنتاجية بنسبة 20%",
      progress: 60,
      deadline: "2024-05-31",
      status: "قيد التنفيذ",
      color: "from-[#1fa39b] to-[#0d8a84]",
    },
    {
      title: "إكمال المشاريع الاستراتيجية",
      description: "تسليم 3 مشاريع استراتيجية في الوقت المحدد",
      progress: 90,
      deadline: "2024-03-31",
      status: "شبه مكتمل",
      color: "from-[#a8d08d] to-[#8bb870]",
    },
  ]

  const kpis = [
    { name: "معدل الإنجاز", current: 92, target: 95, unit: "%" },
    { name: "رضا العملاء", current: 88, target: 90, unit: "%" },
    { name: "المشاريع المكتملة", current: 12, target: 15, unit: "" },
    { name: "ساعات التدريب", current: 45, target: 60, unit: "ساعة" },
  ]

  const achievements = [
    { title: "موظف الشهر", date: "يناير 2024", icon: Award, color: "text-[#5ba0ce]" },
    { title: "أفضل مشروع", date: "ديسمبر 2023", icon: Target, color: "text-[#0088cc]" },
    { title: "تميز في الأداء", date: "نوفمبر 2023", icon: TrendingUp, color: "text-[#1fa39b]" },
  ]

  return (
    <div className="space-y-6">
      {/* Goals */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-[#0088cc]">الأهداف السنوية</h3>
        {goals.map((goal, index) => (
          <div key={index} className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h4 className="text-lg font-bold text-gray-800 mb-2">{goal.title}</h4>
                <p className="text-sm text-gray-600 mb-3">{goal.description}</p>
                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1 text-gray-500">
                    <Calendar className="w-4 h-4" />
                    {goal.deadline}
                  </span>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${goal.color} text-white`}
                  >
                    {goal.status}
                  </span>
                </div>
              </div>
              <div className="text-left">
                <span className={`text-3xl font-bold bg-gradient-to-r ${goal.color} bg-clip-text text-transparent`}>
                  {goal.progress}%
                </span>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`bg-gradient-to-r ${goal.color} h-3 rounded-full transition-all duration-500`}
                style={{ width: `${goal.progress}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      {/* KPIs */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
        <h3 className="text-xl font-bold text-[#0088cc] mb-4">مؤشرات الأداء الرئيسية (KPIs)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {kpis.map((kpi, index) => {
            const percentage = (kpi.current / kpi.target) * 100
            return (
              <div key={index} className="p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-gray-800">{kpi.name}</span>
                  <span className="text-sm text-gray-500">
                    {kpi.current} / {kpi.target} {kpi.unit}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      percentage >= 90 ? "bg-green-500" : percentage >= 70 ? "bg-yellow-500" : "bg-red-500"
                    }`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
        <h3 className="text-xl font-bold text-[#0088cc] mb-4">الإنجازات والجوائز</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon
            return (
              <div
                key={index}
                className="p-4 bg-gradient-to-br from-gray-50 to-white rounded-xl border border-gray-100 hover:shadow-lg transition-all"
              >
                <Icon className={`w-12 h-12 ${achievement.color} mb-3`} />
                <h4 className="font-bold text-gray-800 mb-1">{achievement.title}</h4>
                <p className="text-sm text-gray-500">{achievement.date}</p>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
