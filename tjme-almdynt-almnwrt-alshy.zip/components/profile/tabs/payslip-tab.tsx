"use client"

import { useState } from "react"
import { Download, FileText, Calendar, DollarSign, TrendingUp, Eye } from "lucide-react"
import Image from "next/image"

export function PayslipTab() {
  const [selectedMonth, setSelectedMonth] = useState("2024-12")

  const payslips = [
    {
      id: 1,
      month: "2024-12",
      monthName: "ديسمبر 2024",
      basicSalary: 25000,
      allowances: 8500,
      deductions: 2375,
      netSalary: 31125,
      status: "paid",
    },
    {
      id: 2,
      month: "2024-11",
      monthName: "نوفمبر 2024",
      basicSalary: 25000,
      allowances: 8500,
      deductions: 2375,
      netSalary: 31125,
      status: "paid",
    },
    {
      id: 3,
      month: "2024-10",
      monthName: "أكتوبر 2024",
      basicSalary: 25000,
      allowances: 8000,
      deductions: 2375,
      netSalary: 30625,
      status: "paid",
    },
    {
      id: 4,
      month: "2024-09",
      monthName: "سبتمبر 2024",
      basicSalary: 25000,
      allowances: 8500,
      deductions: 2375,
      netSalary: 31125,
      status: "paid",
    },
    {
      id: 5,
      month: "2024-08",
      monthName: "أغسطس 2024",
      basicSalary: 25000,
      allowances: 9000,
      deductions: 2375,
      netSalary: 31625,
      status: "paid",
    },
    {
      id: 6,
      month: "2024-07",
      monthName: "يوليو 2024",
      basicSalary: 25000,
      allowances: 8500,
      deductions: 2375,
      netSalary: 31125,
      status: "paid",
    },
  ]

  const selectedPayslip = payslips.find((p) => p.month === selectedMonth) || payslips[0]

  const allowancesBreakdown = [
    { name: "بدل سكن", amount: 4000 },
    { name: "بدل مواصلات", amount: 2500 },
    { name: "بدل اتصالات", amount: 1000 },
    { name: "بدل طبيعة عمل", amount: 1000 },
  ]

  const deductionsBreakdown = [{ name: "التأمينات الاجتماعية", amount: 2375 }]

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="bg-gradient-to-br from-[#0088cc] via-[#006ba3] to-[#0088cc] rounded-3xl p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full -ml-24 -mb-24" />

        <div className="relative">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold mb-2">شهادة الراتب</h2>
              <p className="text-white/80">عرض وتحميل كشوف الرواتب الشهرية</p>
            </div>
            <FileText className="w-16 h-16 text-white/20" />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4">
              <DollarSign className="w-6 h-6 mb-2 text-[#8fc8df]" />
              <p className="text-sm text-white/70">الراتب الأساسي</p>
              <p className="text-2xl font-bold">25,000 ر.س</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4">
              <TrendingUp className="w-6 h-6 mb-2 text-[#8fc8df]" />
              <p className="text-sm text-white/70">البدلات</p>
              <p className="text-2xl font-bold">8,500 ر.س</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4">
              <Calendar className="w-6 h-6 mb-2 text-[#8fc8df]" />
              <p className="text-sm text-white/70">صافي الراتب</p>
              <p className="text-2xl font-bold">31,125 ر.س</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Payslip History */}
        <div className="col-span-4">
          <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-6">
            <h3 className="text-xl font-bold text-[#0088cc] mb-4">السجل الشهري</h3>
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {payslips.map((payslip) => (
                <button
                  key={payslip.id}
                  onClick={() => setSelectedMonth(payslip.month)}
                  className={`w-full text-right p-4 rounded-xl transition-all ${
                    selectedMonth === payslip.month
                      ? "bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white shadow-lg"
                      : "bg-gray-50 hover:bg-gray-100"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Calendar className="w-5 h-5" />
                    <span className="font-semibold">{payslip.monthName}</span>
                  </div>
                  <div className="text-sm opacity-90">صافي الراتب: {payslip.netSalary.toLocaleString()} ر.س</div>
                  <div className="flex items-center gap-2 mt-2">
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        selectedMonth === payslip.month ? "bg-white/20" : "bg-green-100 text-green-700"
                      }`}
                    >
                      مدفوع
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Payslip Details */}
        <div className="col-span-8">
          <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-8">
            {/* Header */}
            <div className="flex items-start justify-between mb-8 pb-6 border-b-2 border-gray-100">
              <div>
                <Image src="/logo.png" alt="تجمع المدينة المنورة الصحي" width={120} height={40} className="mb-4" />
                <h3 className="text-2xl font-bold text-[#0088cc] mb-1">كشف راتب</h3>
                <p className="text-gray-600">{selectedPayslip.monthName}</p>
              </div>
              <div className="flex gap-2">
                <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white rounded-xl hover:shadow-lg transition-all">
                  <Download className="w-4 h-4" />
                  تحميل PDF
                </button>
                <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-all">
                  <Eye className="w-4 h-4" />
                  معاينة
                </button>
              </div>
            </div>

            {/* Employee Info */}
            <div className="grid grid-cols-2 gap-6 mb-8 p-6 bg-gray-50 rounded-2xl">
              <div>
                <p className="text-sm text-gray-500 mb-1">اسم الموظف</p>
                <p className="font-semibold text-gray-900">أحمد المالكي</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">الرقم الوظيفي</p>
                <p className="font-semibold text-gray-900">EMP-2024-001</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">الإدارة</p>
                <p className="font-semibold text-gray-900">التسويق الرقمي</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">المسمى الوظيفي</p>
                <p className="font-semibold text-gray-900">مدير التسويق الرقمي</p>
              </div>
            </div>

            {/* Salary Breakdown */}
            <div className="space-y-6">
              {/* Earnings */}
              <div>
                <h4 className="text-lg font-bold text-[#0088cc] mb-4">المستحقات</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-xl">
                    <span className="text-gray-700">الراتب الأساسي</span>
                    <span className="font-bold text-green-700">{selectedPayslip.basicSalary.toLocaleString()} ر.س</span>
                  </div>
                  {allowancesBreakdown.map((allowance, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-xl">
                      <span className="text-gray-700">{allowance.name}</span>
                      <span className="font-bold text-green-700">{allowance.amount.toLocaleString()} ر.س</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between p-4 bg-green-100 rounded-xl border-2 border-green-200">
                    <span className="font-bold text-gray-900">إجمالي المستحقات</span>
                    <span className="font-bold text-green-700 text-xl">
                      {(selectedPayslip.basicSalary + selectedPayslip.allowances).toLocaleString()} ر.س
                    </span>
                  </div>
                </div>
              </div>

              {/* Deductions */}
              <div>
                <h4 className="text-lg font-bold text-[#0088cc] mb-4">الاستقطاعات</h4>
                <div className="space-y-3">
                  {deductionsBreakdown.map((deduction, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-xl">
                      <span className="text-gray-700">{deduction.name}</span>
                      <span className="font-bold text-red-700">{deduction.amount.toLocaleString()} ر.س</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between p-4 bg-red-100 rounded-xl border-2 border-red-200">
                    <span className="font-bold text-gray-900">إجمالي الاستقطاعات</span>
                    <span className="font-bold text-red-700 text-xl">
                      {selectedPayslip.deductions.toLocaleString()} ر.س
                    </span>
                  </div>
                </div>
              </div>

              {/* Net Salary */}
              <div className="p-6 bg-gradient-to-r from-[#0088cc] to-[#006ba3] rounded-2xl text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/80 mb-1">صافي الراتب المستحق</p>
                    <p className="text-4xl font-bold">{selectedPayslip.netSalary.toLocaleString()} ر.س</p>
                  </div>
                  <DollarSign className="w-16 h-16 text-white/20" />
                </div>
              </div>
            </div>

            {/* Footer Note */}
            <div className="mt-8 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <p className="text-sm text-gray-600 text-center">
                تم إيداع الراتب في حسابك البنكي المنتهي بـ ****1234 بتاريخ {selectedPayslip.monthName}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
