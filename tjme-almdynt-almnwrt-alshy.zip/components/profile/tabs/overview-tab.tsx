"use client"

import {
  Mail,
  Users,
  Award,
  TrendingUp,
  Calendar,
  Clock,
  ChevronLeft,
  ChevronRight,
  Star,
  Paperclip,
  Archive,
  Trash2,
} from "lucide-react"
import { useState } from "react"

export function OverviewTab() {
  const [selectedEmail, setSelectedEmail] = useState(0)
  const [currentMonth, setCurrentMonth] = useState(new Date())

  const emails = [
    {
      id: 1,
      from: "محمد السعيد",
      subject: "تحديث: مشروع تطوير البوابة الإلكترونية",
      preview: "السلام عليكم، أود إعلامكم بآخر التحديثات على مشروع البوابة...",
      time: "10:30 ص",
      read: false,
      starred: true,
      hasAttachment: true,
      body: "السلام عليكم ورحمة الله وبركاته،\n\nأود إعلامكم بآخر التحديثات على مشروع البوابة الإلكترونية. تم الانتهاء من المرحلة الأولى بنجاح وننتقل الآن إلى المرحلة الثانية.\n\nالمرفقات تحتوي على تقرير مفصل بالإنجازات.\n\nمع تحياتي،\nمحمد السعيد",
    },
    {
      id: 2,
      from: "إدارة الموارد البشرية",
      subject: "موافقة على طلب الإجازة",
      preview: "تم الموافقة على طلب إجازتك من تاريخ 15/03/2024 إلى 20/03/2024",
      time: "أمس",
      read: true,
      starred: false,
      hasAttachment: false,
      body: "عزيزي الموظف،\n\nنفيدكم بأنه تم الموافقة على طلب إجازتك السنوية من تاريخ 15/03/2024 إلى 20/03/2024.\n\nنتمنى لك إجازة سعيدة.\n\nإدارة الموارد البشرية",
    },
    {
      id: 3,
      from: "فريق التدريب",
      subject: "دعوة: ورشة عمل إدارة المشاريع",
      preview: "نسعد بدعوتكم لحضور ورشة عمل حول إدارة المشاريع الاحترافية...",
      time: "أمس",
      read: false,
      starred: false,
      hasAttachment: true,
      body: "السلام عليكم،\n\nنسعد بدعوتكم لحضور ورشة عمل حول إدارة المشاريع الاحترافية يوم الأحد القادم الساعة 10 صباحاً.\n\nالرجاء تأكيد الحضور.\n\nفريق التدريب",
    },
    {
      id: 4,
      from: "نورة القحطاني",
      subject: "Re: مراجعة التقرير الشهري",
      preview: "شكراً على التقرير المفصل، لدي بعض الملاحظات البسيطة...",
      time: "الأحد",
      read: true,
      starred: true,
      hasAttachment: false,
      body: "مرحباً،\n\nشكراً على التقرير المفصل والمجهود الرائع. لدي بعض الملاحظات البسيطة نتناقش فيها في الاجتماع القادم.\n\nبارك الله فيك،\nنورة القحطاني",
    },
    {
      id: 5,
      from: "الدعم التقني",
      subject: "تحديث النظام المقرر",
      preview: "سيتم إجراء صيانة دورية للأنظمة يوم الخميس من 12 ص إلى 2 ص",
      time: "الأحد",
      read: true,
      starred: false,
      hasAttachment: false,
      body: "إشعار مهم،\n\nسيتم إجراء صيانة دورية للأنظمة يوم الخميس من الساعة 12 منتصف الليل إلى الساعة 2 صباحاً.\n\nنعتذر عن أي إزعاج.\n\nالدعم التقني",
    },
    {
      id: 6,
      from: "فريق المشاريع",
      subject: "اجتماع فريق العمل الأسبوعي",
      preview: "تذكير باجتماع فريق العمل الأسبوعي يوم الاثنين الساعة 2 ظهراً",
      time: "السبت",
      read: false,
      starred: false,
      hasAttachment: false,
      body: "مرحباً بالجميع،\n\nتذكير باجتماع فريق العمل الأسبوعي يوم الاثنين الساعة 2 ظهراً في قاعة الاجتماعات الرئيسية.\n\nفريق المشاريع",
    },
    {
      id: 7,
      from: "أحمد الدوسري",
      subject: "مشاركة ملف: استراتيجية 2024",
      preview: "أرفق لكم ملف استراتيجية الهيئة لعام 2024 للاطلاع",
      time: "الجمعة",
      read: true,
      starred: false,
      hasAttachment: true,
      body: "مساء الخير،\n\nأرفق لكم ملف استراتيجية الهيئة لعام 2024 للاطلاع والاستفادة منه في خططكم.\n\nأحمد الدوسري",
    },
    {
      id: 8,
      from: "المالية",
      subject: "كشف الراتب - مارس 2024",
      preview: "تم إصدار كشف راتب شهر مارس 2024، يمكنكم تحميله من المرفقات",
      time: "الخميس",
      read: true,
      starred: true,
      hasAttachment: true,
      body: "عزيزنا الموظف،\n\nتم إصدار كشف راتب شهر مارس 2024. يمكنكم تحميله من المرفقات.\n\nإدارة المالية",
    },
    {
      id: 9,
      from: "سارة المطيري",
      subject: "استفسار عن التقرير السنوي",
      preview: "لدي بعض الاستفسارات حول البيانات المذكورة في التقرير السنوي...",
      time: "الأربعاء",
      read: false,
      starred: false,
      hasAttachment: false,
      body: "السلام عليكم،\n\nلدي بعض الاستفسارات حول البيانات المذكورة في التقرير السنوي. هل يمكننا مناقشتها؟\n\nسارة المطيري",
    },
    {
      id: 10,
      from: "إدارة التقنية",
      subject: "تحديث سياسة الأمن السيبراني",
      preview: "تم تحديث سياسة الأمن السيبراني، الرجاء الاطلاع والالتزام...",
      time: "الثلاثاء",
      read: true,
      starred: false,
      hasAttachment: true,
      body: "إلى جميع الموظفين،\n\nتم تحديث سياسة الأمن السيبراني في الهيئة. الرجاء الاطلاع على المرفقات والالتزام بالتعليمات الجديدة.\n\nإدارة التقنية",
    },
  ]

  const upcomingEvents = [
    { title: "اجتماع فريق التسويق", time: "10:00 ص", date: "الاثنين، 25 مارس", color: "bg-[#0088cc]" },
    { title: "ورشة عمل: إدارة المشاريع", time: "2:00 م", date: "الثلاثاء، 26 مارس", color: "bg-[#1fa39b]" },
    { title: "مراجعة الأداء الفصلي", time: "11:00 ص", date: "الأربعاء، 27 مارس", color: "bg-[#a8d08d]" },
    { title: "لقاء مع العملاء", time: "3:00 م", date: "الخميس، 28 مارس", color: "bg-[#5ba0ce]" },
  ]

  // Generate calendar days
  const generateCalendarDays = () => {
    const year = currentMonth.getFullYear()
    const month = currentMonth.getMonth()
    const firstDay = new Date(year, month, 1).getDay()
    const daysInMonth = new Date(year, month + 1, 0).getDate()
    const days = []

    // Add empty cells for days before month starts
    for (let i = 0; i < firstDay; i++) {
      days.push(null)
    }

    // Add days of month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i)
    }

    return days
  }

  const calendarDays = generateCalendarDays()
  const today = new Date().getDate()
  const isCurrentMonth = currentMonth.getMonth() === new Date().getMonth()

  const monthNames = [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر",
  ]
  const dayNames = ["أح", "إث", "ثل", "أر", "خم", "جم", "سب"]

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-[#0088cc] to-[#006ba3] rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <Award className="w-8 h-8" />
            <span className="text-3xl font-bold">95%</span>
          </div>
          <p className="text-sm opacity-90">معدل الأداء</p>
        </div>

        <div className="bg-gradient-to-br from-[#1fa39b] to-[#0d8a84] rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8" />
            <span className="text-3xl font-bold">12</span>
          </div>
          <p className="text-sm opacity-90">مشروع مكتمل</p>
        </div>

        <div className="bg-gradient-to-br from-[#a8d08d] to-[#8bb870] rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8" />
            <span className="text-3xl font-bold">3</span>
          </div>
          <p className="text-sm opacity-90">أعضاء الفريق</p>
        </div>

        <div className="bg-gradient-to-br from-[#5ba0ce] to-[#4189b3] rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <Mail className="w-8 h-8" />
            <span className="text-3xl font-bold">5</span>
          </div>
          <p className="text-sm opacity-90">رسائل جديدة</p>
        </div>
      </div>

      {/* Email and Calendar Section */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Email Section - 60% */}
        <div className="lg:col-span-3 bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden">
          <div className="border-b border-gray-200 p-4 bg-gradient-to-r from-[#0088cc] to-[#006ba3]">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Mail className="w-6 h-6" />
              البريد الإلكتروني
            </h3>
          </div>

          <div className="grid grid-cols-12 h-[600px]">
            {/* Inbox List */}
            <div className="col-span-5 border-l border-gray-200 overflow-y-auto">
              {emails.map((email, index) => (
                <div
                  key={email.id}
                  onClick={() => setSelectedEmail(index)}
                  className={`p-4 border-b border-gray-100 cursor-pointer transition-all hover:bg-gray-50 ${
                    selectedEmail === index ? "bg-[#0088cc]/5 border-r-4 border-r-[#0088cc]" : ""
                  } ${!email.read ? "bg-blue-50/30" : ""}`}
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        {email.starred && <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />}
                        <p
                          className={`font-semibold text-sm truncate ${!email.read ? "text-gray-900" : "text-gray-600"}`}
                        >
                          {email.from}
                        </p>
                      </div>
                      <p
                        className={`text-sm mb-1 truncate ${!email.read ? "font-semibold text-gray-900" : "text-gray-700"}`}
                      >
                        {email.subject}
                      </p>
                      <p className="text-xs text-gray-500 truncate">{email.preview}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {email.hasAttachment && <Paperclip className="w-3 h-3 text-gray-400" />}
                        <span className="text-xs text-gray-400">{email.time}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Email Preview */}
            <div className="col-span-7 overflow-y-auto">
              {emails[selectedEmail] && (
                <div className="p-6">
                  <div className="mb-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h4 className="text-xl font-bold text-gray-900 mb-2">{emails[selectedEmail].subject}</h4>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0088cc] to-[#006ba3] flex items-center justify-center text-white font-bold">
                            {emails[selectedEmail].from.charAt(0)}
                          </div>
                          <div>
                            <p className="font-semibold text-gray-800">{emails[selectedEmail].from}</p>
                            <p className="text-sm text-gray-500">{emails[selectedEmail].time}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                          <Archive className="w-5 h-5 text-gray-600" />
                        </button>
                        <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                          <Trash2 className="w-5 h-5 text-gray-600" />
                        </button>
                        <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                          <Star
                            className={`w-5 h-5 ${emails[selectedEmail].starred ? "text-yellow-500 fill-yellow-500" : "text-gray-600"}`}
                          />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="prose max-w-none">
                    <p className="text-gray-700 whitespace-pre-line leading-relaxed">{emails[selectedEmail].body}</p>
                  </div>

                  {emails[selectedEmail].hasAttachment && (
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <p className="text-sm font-semibold text-gray-700 mb-3">المرفقات</p>
                      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                        <Paperclip className="w-5 h-5 text-[#0088cc]" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-800">تقرير_المشروع.pdf</p>
                          <p className="text-xs text-gray-500">2.4 MB</p>
                        </div>
                        <button className="text-sm text-[#0088cc] font-semibold hover:underline">تحميل</button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Calendar Section - 40% */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden">
          <div className="border-b border-gray-200 p-4 bg-gradient-to-r from-[#1fa39b] to-[#0d8a84]">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Calendar className="w-6 h-6" />
              التقويم
            </h3>
          </div>

          <div className="p-4">
            {/* Calendar Header */}
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </button>
              <h4 className="font-bold text-gray-800">
                {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
              </h4>
              <button
                onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            {/* Calendar Grid */}
            <div className="mb-4">
              {/* Day Names */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {dayNames.map((day) => (
                  <div key={day} className="text-center text-xs font-semibold text-gray-500 py-1">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Days */}
              <div className="grid grid-cols-7 gap-1">
                {calendarDays.map((day, index) => (
                  <div
                    key={index}
                    className={`aspect-square flex items-center justify-center text-sm rounded-lg transition-all ${
                      day === null
                        ? ""
                        : day === today && isCurrentMonth
                          ? "bg-gradient-to-br from-[#0088cc] to-[#006ba3] text-white font-bold"
                          : "hover:bg-gray-100 cursor-pointer text-gray-700"
                    }`}
                  >
                    {day}
                  </div>
                ))}
              </div>
            </div>

            {/* Upcoming Events */}
            <div>
              <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#0088cc]" />
                الفعاليات القادمة
              </h4>
              <div className="space-y-3 max-h-[220px] overflow-y-auto">
                {upcomingEvents.map((event, index) => (
                  <div key={index} className="flex gap-3 p-3 bg-gray-50 rounded-lg hover:shadow-md transition-all">
                    <div className={`w-1 ${event.color} rounded-full`}></div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800 truncate">{event.title}</p>
                      <p className="text-xs text-gray-500">{event.date}</p>
                      <p className="text-xs text-[#0088cc] font-medium mt-1">{event.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
