"use client"

import { useState } from "react"
import { LayoutGrid, Briefcase, FileText, Calendar, Clock, Target, Receipt } from "lucide-react"
import { OverviewTab } from "./tabs/overview-tab"
import { ServicesTab } from "./tabs/services-tab"
import { RequestsTab } from "./tabs/requests-tab"
import { LeaveTab } from "./tabs/leave-tab"
import { AttendanceTab } from "./tabs/attendance-tab"
import { GoalsTab } from "./tabs/goals-tab"
import { PayslipTab } from "./tabs/payslip-tab"

export function ProfileTabs() {
  const [activeTab, setActiveTab] = useState("overview")

  const tabs = [
    { id: "overview", label: "نظرة عامة", icon: LayoutGrid },
    { id: "services", label: "الخدمات", icon: Briefcase },
    { id: "requests", label: "الطلبات", icon: FileText },
    { id: "leave", label: "الإجازات", icon: Calendar },
    { id: "attendance", label: "الحضور", icon: Clock },
    { id: "payslip", label: "شهادة الراتب", icon: Receipt },
    { id: "goals", label: "الأهداف والمؤشرات", icon: Target },
  ]

  return (
    <div>
      {/* Tabs Navigation */}
      <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-2 mb-6">
        <div className="flex items-center gap-2 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? "bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white shadow-lg"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
              >
                <Icon className="w-5 h-5" />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === "overview" && <OverviewTab />}
        {activeTab === "services" && <ServicesTab />}
        {activeTab === "requests" && <RequestsTab />}
        {activeTab === "leave" && <LeaveTab />}
        {activeTab === "attendance" && <AttendanceTab />}
        {activeTab === "payslip" && <PayslipTab />}
        {activeTab === "goals" && <GoalsTab />}
      </div>
    </div>
  )
}
