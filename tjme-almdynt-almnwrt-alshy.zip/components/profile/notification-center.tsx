"use client"

import { Bell, X, CheckCircle, AlertCircle, Info } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

export function NotificationCenter() {
  const [isExpanded, setIsExpanded] = useState(false)

  const notifications = [
    {
      id: 1,
      type: "success",
      title: "تمت الموافقة على طلب الإجازة",
      message: "تم الموافقة على طلب إجازتك من 15-20 ديسمبر",
      time: "منذ 5 دقائق",
      unread: true,
    },
    {
      id: 2,
      type: "info",
      title: "تحديث في نظام الحضور",
      message: "تم تسجيل حضورك اليوم في الساعة 8:15 صباحاً",
      time: "منذ ساعة",
      unread: true,
    },
    {
      id: 3,
      type: "warning",
      title: "اجتماع قادم",
      message: "لديك اجتماع مع فريق التسويق الساعة 2:00 مساءً",
      time: "منذ 3 ساعات",
      unread: false,
    },
    {
      id: 4,
      type: "info",
      title: "رسالة شكر جديدة",
      message: "أرسل لك محمد العتيبي بطاقة شكر",
      time: "أمس",
      unread: false,
    },
  ]

  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case "warning":
        return <AlertCircle className="w-5 h-5 text-orange-600" />
      case "info":
        return <Info className="w-5 h-5 text-blue-600" />
      default:
        return <Bell className="w-5 h-5 text-gray-600" />
    }
  }

  const unreadCount = notifications.filter((n) => n.unread).length

  return (
    null
  )
}
