"use client"

import Image from "next/image"
import { Quote } from "lucide-react"

export function CEOMessage() {
  return (
    <div className="bg-gradient-to-br from-[#0088cc]/5 via-white to-[#a8d08d]/5 rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
        {/* CEO Image Section */}
        <div className="lg:col-span-4 relative">
          <div className="relative h-48 sm:h-64 lg:h-full min-h-[280px]">
            <Image src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download-mQ82fS56z1o4xVRDglOWzwp81Xc1yi.jpg" alt="الرئيس التنفيذي" fill className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#006ba3]/80 via-[#006ba3]/20 to-transparent" />

            {/* CEO Info Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
              <h3 className="text-xl sm:text-2xl font-bold mb-1">ناصر بن محمد الحقباني </h3>
              <p className="text-xs sm:text-sm text-white/90">الرئيس التنفيذي</p>
              <p className="text-xs text-white/80 mt-0.5">لشركة الصحة القابضة</p>
            </div>
          </div>
        </div>

        {/* Message Content */}
        <div className="lg:col-span-8 p-4 sm:p-6 lg:p-8 flex flex-col justify-center">
          <div className="mb-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-[#0088cc] to-[#006ba3] flex items-center justify-center shadow-lg">
                <Quote className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-[#006ba3]">كلمة الرئيس التنفيذي</h2>
            </div>
            <div className="h-1 w-20 bg-gradient-to-r from-[#0088cc] to-[#a8d08d] rounded-full"></div>
          </div>

          <div className="space-y-3 text-gray-700 text-sm sm:text-base leading-relaxed">
            <p className="text-justify">
              {"تأسست الشركة في 3 ذو القعدة 1443، وذلك تنفيذاً لقرار مجلس الوزراء رقم (469) بتاريخ 1443/08/19هـ القاضي بتأسيس شركة الصحة القابضة، والموافقة على تنظيم مركز التأمين الصحي الوطني. تم تأسيس الشركة ككيان مستقل مسؤول عن الاستثمار في القطاع الصحي وتطويره. أتى القرار تجسيدًا للدعم والاهتمام الكبيرين لتطوير خدمات الرعاية الصحية المقدمة للمستفيدين، وتسخير كل الإمكانات لتعزيز جودة وكفاءة تلك الخدمات سعيًا لتحقيق المستهدفات الطموحة لرؤية المملكة 2030."}
            </p>
            
            <p className="font-semibold text-[#0088cc]">معاً نصنع قصة نجاح استثنائية تفخر بها المملكة والعالم.</p>
          </div>

          {/* Signature */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <p className="text-base sm:text-lg font-bold text-[#006ba3]">{"ناصر بن محمد الحقباني"}  </p>
                <p className="text-xs sm:text-sm text-gray-600">{"الرئيس التنفيذي لشركة الصحة القابضة"}</p>
              </div>
              <div className="hidden sm:block w-16 h-16 relative opacity-30">
                <Image src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-5WBlXOa7llioCR23CkhY6rXPDAJFtF.png" alt="Saudi Tourism Authority" fill className="object-contain" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
