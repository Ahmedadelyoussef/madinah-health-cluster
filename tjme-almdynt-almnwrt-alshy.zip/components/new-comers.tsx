"use client"

import { UserPlus, Briefcase, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const newEmployees = [
  {
    name: "عبدالله محمد السلمان",
    position: "مدير تطوير الأعمال",
    department: "التطوير السياحي",
    startDate: "1 مارس 2024",
    image: "/images/new-employee-1.jpg",
    background: "#51c041",
  },
  {
    name: "ريم سعد الشهراني",
    position: "أخصائي تسويق رقمي",
    department: "التسويق والاتصال",
    startDate: "5 مارس 2024",
    image: "/images/new-employee-2.jpg",
    background: "#009aac",
  },
  {
    name: "فهد أحمد الزهراني",
    position: "مطور تطبيقات",
    department: "التقنية والمعلومات",
    startDate: "10 مارس 2024",
    image: "/images/new-employee-3.jpg",
    background: "#be008d",
  },
]

export function NewComers() {
  return (
    <div className="bg-gradient-to-br from-[#51c041]/5 to-white rounded-3xl p-8 shadow-lg border border-[#51c041]/20 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-[#51c041]/10 flex items-center justify-center">
          <UserPlus className="w-6 h-6 text-[#51c041]" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-[#3e6e2d]">الموظفون الجدد</h2>
          <p className="text-sm text-gray-600">مرحباً بكم في فريقنا</p>
        </div>
      </div>

      <div className="space-y-4">
        {newEmployees.map((employee, index) => (
          <div
            key={index}
            className="group relative p-5 rounded-2xl bg-white border border-gray-100 hover:shadow-xl transition-all overflow-hidden"
          >
            {/* Background pattern */}
            <div
              className="absolute top-0 left-0 w-full h-1 transition-all group-hover:h-2"
              style={{ backgroundColor: employee.background }}
            />

            <div className="flex items-center gap-4 mt-2">
              <div className="relative">
                <div
                  className="w-20 h-20 rounded-2xl overflow-hidden ring-2 ring-gray-100 group-hover:ring-4 group-hover:scale-105 transition-all"
                  style={{ borderColor: `${employee.background}40` }}
                >
                  <Image
                    src={employee.image || "/placeholder.svg"}
                    alt={employee.name}
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div
                  className="absolute -top-2 -right-2 px-2 py-1 rounded-lg text-xs font-bold text-white shadow-lg"
                  style={{ backgroundColor: employee.background }}
                >
                  جديد
                </div>
              </div>

              <div className="flex-1">
                <h3 className="font-bold text-gray-800 text-lg mb-1">{employee.name}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                  <Briefcase className="w-4 h-4" />
                  <span>{employee.position}</span>
                </div>
                <p className="text-sm text-gray-500 mb-2">{employee.department}</p>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Calendar className="w-3 h-3" />
                  <span>تاريخ الانضمام: {employee.startDate}</span>
                </div>
              </div>

              <Button
                size="sm"
                variant="outline"
                className="opacity-0 group-hover:opacity-100 transition-opacity bg-transparent"
                style={{ borderColor: employee.background, color: employee.background }}
              >
                قل مرحباً
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
