"use client"

import { useState } from "react"
import Image from "next/image"
import { Video, Phone, MoreVertical, Users, MessageCircle, Calendar, Bell } from "lucide-react"

interface Chat {
  id: number
  name: string
  image: string
  lastMessage: string
  timestamp: string
  unread: number
  isOnline: boolean
}

export function TeamsMockup() {
  const [chats] = useState<Chat[]>([
    {
      id: 1,
      name: "فريق التطوير",
      image: "/saudi-team-member-1.jpg",
      lastMessage: "تم رفع التحديث الجديد",
      timestamp: "10:30 ص",
      unread: 3,
      isOnline: true,
    },
    {
      id: 2,
      name: "سارة الغامدي",
      image: "/saudi-team-member-2.jpg",
      lastMessage: "شكراً على المساعدة",
      timestamp: "أمس",
      unread: 0,
      isOnline: true,
    },
    {
      id: 3,
      name: "قسم التسويق",
      image: "/saudi-team-member-4.jpg",
      lastMessage: "اجتماع اليوم الساعة 3",
      timestamp: "أمس",
      unread: 1,
      isOnline: false,
    },
    {
      id: 4,
      name: "محمد العتيبي",
      image: "/saudi-team-member-3.jpg",
      lastMessage: "هل يمكنك مراجعة الكود؟",
      timestamp: "الإثنين",
      unread: 0,
      isOnline: true,
    },
  ])

  const [selectedChat, setSelectedChat] = useState<Chat>(chats[0])

  return (
    <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden flex flex-col h-[450px]">
      <div className="bg-gradient-to-r from-[#464EB8] to-[#5B6AC4] p-3 text-white flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Users className="w-4 h-4" />
          </div>
          <h3 className="text-base font-bold">Microsoft Teams</h3>
        </div>
        <div className="flex items-center gap-1">
          <button className="w-7 h-7 rounded-lg bg-white/20 hover:bg-white/30 flex items-center justify-center transition-all">
            <Video className="w-3.5 h-3.5" />
          </button>
          <button className="w-7 h-7 rounded-lg bg-white/20 hover:bg-white/30 flex items-center justify-center transition-all">
            <Phone className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 border-b border-gray-200">
        <div className="grid grid-cols-3 gap-2">
          <div className="flex items-center gap-2 bg-white rounded-xl p-2 shadow-sm">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#464EB8] to-[#5B6AC4] flex items-center justify-center text-white">
              <MessageCircle className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-gray-900">12</div>
              <div className="text-[10px] text-gray-500">محادثات</div>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-white rounded-xl p-2 shadow-sm">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#be008d] to-[#78006e] flex items-center justify-center text-white">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-gray-900">3</div>
              <div className="text-[10px] text-gray-500">اجتماعات</div>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-white rounded-xl p-2 shadow-sm">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#3dc2c2] to-[#009aac] flex items-center justify-center text-white">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-gray-900">8</div>
              <div className="text-[10px] text-gray-500">إشعارات</div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex min-h-0">
        {/* قائمة المحادثات */}
        <div className="w-2/5 border-l border-gray-200 bg-gray-50 overflow-y-auto">
          {chats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setSelectedChat(chat)}
              className={`w-full p-2.5 flex items-center gap-2 text-right hover:bg-gray-100 transition-all border-b border-gray-100 ${
                selectedChat.id === chat.id ? "bg-blue-50 border-l-2 border-l-[#464EB8]" : ""
              }`}
            >
              <div className="relative flex-shrink-0">
                <Image
                  src={chat.image || "/placeholder.svg"}
                  alt={chat.name}
                  width={36}
                  height={36}
                  className="rounded-full"
                />
                {chat.isOnline && (
                  <div className="absolute bottom-0 left-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <h4 className="font-semibold text-xs text-gray-900 truncate">{chat.name}</h4>
                  <span className="text-[10px] text-gray-500">{chat.timestamp}</span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-[11px] text-gray-600 truncate">{chat.lastMessage}</p>
                  {chat.unread > 0 && (
                    <span className="min-w-[18px] h-4 px-1.5 bg-gradient-to-r from-[#be008d] to-[#78006e] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {chat.unread}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* نافذة المحادثة */}
        <div className="flex-1 flex flex-col bg-white min-h-0">
          {/* Header المحادثة */}
          <div className="p-2.5 border-b border-gray-200 bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image
                  src={selectedChat.image || "/placeholder.svg"}
                  alt={selectedChat.name}
                  width={32}
                  height={32}
                  className="rounded-full"
                />
                <div>
                  <h3 className="font-semibold text-xs text-gray-900">{selectedChat.name}</h3>
                  <p className="text-[10px] text-gray-500">{selectedChat.isOnline ? "متصل الآن" : "غير متصل"}</p>
                </div>
              </div>
              <button className="w-7 h-7 rounded-lg bg-gray-200 text-gray-600 hover:bg-gray-300 flex items-center justify-center transition-all">
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* منطقة الرسائل */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-gradient-to-b from-gray-50 to-white">
            <div className="flex justify-end">
              <div className="max-w-[75%] bg-white border border-gray-200 rounded-xl p-2 shadow-sm">
                <p className="text-[10px] font-semibold mb-1 text-[#464EB8]">محمد العتيبي</p>
                <p className="text-[11px] text-gray-800 leading-relaxed">
                  صباح الخير! كيف تسير الأمور مع المشروع الجديد؟
                </p>
                <p className="text-[9px] text-gray-500 mt-1">9:15 ص</p>
              </div>
            </div>

            <div className="flex justify-start">
              <div className="max-w-[75%] bg-gradient-to-r from-[#464EB8] to-[#5B6AC4] text-white rounded-xl p-2 shadow-sm">
                <p className="text-[11px] leading-relaxed">
                  صباح النور! الأمور تسير بشكل ممتاز. تم إنجاز 80% من المهام.
                </p>
                <p className="text-[9px] text-white/70 mt-1">9:20 ص</p>
              </div>
            </div>

            <div className="flex justify-end">
              <div className="max-w-[75%] bg-white border border-gray-200 rounded-xl p-2 shadow-sm">
                <p className="text-[10px] font-semibold mb-1 text-[#464EB8]">سارة الغامدي</p>
                <p className="text-[11px] text-gray-800 leading-relaxed">رائع! هل تحتاجون أي مساعدة؟</p>
                <p className="text-[9px] text-gray-500 mt-1">9:45 ص</p>
              </div>
            </div>

            <div className="flex justify-start">
              <div className="max-w-[75%] bg-gradient-to-r from-[#464EB8] to-[#5B6AC4] text-white rounded-xl p-2 shadow-sm">
                <p className="text-[11px] leading-relaxed">نعم، سنحتاج مساعدتكم في الحملة الترويجية</p>
                <p className="text-[9px] text-white/70 mt-1">10:00 ص</p>
              </div>
            </div>
          </div>

          {/* حقل الإدخال */}
          <div className="p-2 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                placeholder="اكتب رسالة..."
                className="flex-1 p-2 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#464EB8]/50"
              />
              <button className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#464EB8] to-[#5B6AC4] text-white hover:opacity-90 flex items-center justify-center transition-all shadow-md">
                <svg
                  className="w-3.5 h-3.5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
