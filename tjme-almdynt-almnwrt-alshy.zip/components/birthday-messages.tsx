"use client"

import { useState } from "react"
import { Cake, Gift, PartyPopper, Send, X } from "lucide-react"
import { Button } from "@/components/ui/button"

const birthdays = [
  { name: "أحمد محمد العتيبي", department: "التسويق", date: "اليوم", image: "/professional-saudi-man.jpg" },
  { name: "فاطمة عبدالله", department: "الموارد البشرية", date: "غداً", image: "/professional-saudi-woman-hijab.jpg" },
  { name: "خالد سعد الغامدي", department: "التقنية", date: "بعد يومين", image: "/professional-saudi-man-glasses.jpg" },
]

export function BirthdayMessages() {
  const [selectedPerson, setSelectedPerson] = useState<(typeof birthdays)[0] | null>(null)
  const [message, setMessage] = useState("")
  const [sent, setSent] = useState<string[]>([])

  const handleSendWish = () => {
    if (selectedPerson) {
      setSent([...sent, selectedPerson.name])
      setSelectedPerson(null)
      setMessage("")
    }
  }

  return (
    <div className="bg-gradient-to-br from-[#ff424c]/5 via-[#ff8300]/5 to-white rounded-3xl p-6 shadow-lg border border-[#ff424c]/20 h-full relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 opacity-10">
        <PartyPopper className="w-32 h-32 text-[#ff424c]" />
      </div>

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ff424c] to-[#ff8300] flex items-center justify-center">
            <Cake className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-bold text-[#3e6e2d]">أعياد الميلاد</h2>
        </div>

        <div className="space-y-4">
          {birthdays.map((person, index) => (
            <div
              key={index}
              className="group relative p-4 rounded-2xl bg-white border border-gray-100 hover:shadow-lg transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-14 h-14 rounded-full overflow-hidden ring-2 ring-[#ff424c]/20">
                    <img
                      src={person.image || "/placeholder.svg"}
                      alt={person.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-[#ff424c] rounded-full flex items-center justify-center">
                    <Cake className="w-3 h-3 text-white" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-800 text-sm truncate">{person.name}</h3>
                  <p className="text-xs text-gray-600">{person.department}</p>
                  <p className="text-xs text-[#ff424c] font-medium mt-0.5">{person.date}</p>
                </div>

                {sent.includes(person.name) ? (
                  <span className="text-xs text-green-600 font-medium bg-green-50 px-2 py-1 rounded-full">
                    تم الإرسال
                  </span>
                ) : (
                  <Button
                    size="sm"
                    onClick={() => setSelectedPerson(person)}
                    className="bg-gradient-to-r from-[#ff424c] to-[#ff8300] hover:shadow-lg text-xs px-3 py-1 h-8"
                  >
                    <Gift className="w-3 h-3 ml-1" />
                    تهنئة
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        <Button variant="outline" className="w-full mt-4 border-[#ff424c]/20 hover:bg-[#ff424c]/5 bg-transparent">
          عرض جميع أعياد الميلاد هذا الشهر
        </Button>
      </div>

      {selectedPerson && (
        <>
          <div className="fixed inset-0 bg-black/50 z-[9998]" onClick={() => setSelectedPerson(null)} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-md bg-white rounded-2xl shadow-2xl z-[9999] overflow-hidden">
            <div className="bg-gradient-to-r from-[#ff424c] to-[#ff8300] p-4 text-white">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg">إرسال تهنئة</h3>
                <button onClick={() => setSelectedPerson(null)} className="hover:bg-white/20 rounded-full p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-full overflow-hidden ring-2 ring-[#ff424c]/20">
                  <img
                    src={selectedPerson.image || "/placeholder.svg"}
                    alt={selectedPerson.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">{selectedPerson.name}</h4>
                  <p className="text-sm text-gray-600">{selectedPerson.department}</p>
                </div>
              </div>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="اكتب رسالة التهنئة هنا..."
                className="w-full p-3 border border-gray-200 rounded-xl resize-none h-28 focus:outline-none focus:ring-2 focus:ring-[#ff424c]/30"
              />
              <div className="flex gap-2 mt-4">
                <Button
                  onClick={handleSendWish}
                  className="flex-1 bg-gradient-to-r from-[#ff424c] to-[#ff8300] hover:shadow-lg"
                >
                  <Send className="w-4 h-4 ml-2" />
                  إرسال التهنئة
                </Button>
                <Button variant="outline" onClick={() => setSelectedPerson(null)} className="border-gray-200">
                  إلغاء
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
