"use client"

import { Button } from "@/components/ui/button"
import { Bell, User, Search, X, Globe, LogOut, Menu, AlertCircle, CheckCircle, Info } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState, useRef, useEffect } from "react"

type NotificationType = "urgent" | "important" | "normal" | "info"

interface Notification {
  id: number
  title: string
  message: string
  type: NotificationType
  time: string
  isRead: boolean
}

const notifications: Notification[] = [
  {
    id: 1,
    title: "تحديث عاجل: اجتماع طارئ",
    message: "اجتماع طارئ مع الإدارة العليا الساعة 3 مساءً",
    type: "urgent",
    time: "منذ 5 دقائق",
    isRead: false,
  },
  {
    id: 2,
    title: "موعد تسليم التقارير الشهرية",
    message: "آخر موعد لتسليم التقارير الشهرية",
    type: "important",
    time: "منذ 30 دقيقة",
    isRead: false,
  },
  {
    id: 3,
    title: "تهانينا! تم الموافقة على طلبك",
    message: "تمت الموافقة على طلب الإجازة",
    type: "info",
    time: "منذ ساعة",
    isRead: true,
  },
  {
    id: 4,
    title: "تحديث النظام",
    message: "صيانة يوم السبت من 12-2 صباحاً",
    type: "normal",
    time: "منذ ساعتين",
    isRead: false,
  },
  {
    id: 5,
    title: "دورة تدريبية جديدة",
    message: "دورة القيادة الفعالة متاحة للتسجيل",
    type: "important",
    time: "منذ 3 ساعات",
    isRead: false,
  },
  {
    id: 6,
    title: "رسالة من الموارد البشرية",
    message: "يرجى تحديث بياناتك الشخصية",
    type: "normal",
    time: "منذ 4 ساعات",
    isRead: true,
  },
  {
    id: 7,
    title: "اجتماع فريق التسويق",
    message: "اجتماع أسبوعي غداً الساعة 10 صباحاً",
    type: "normal",
    time: "منذ 5 ساعات",
    isRead: false,
  },
  {
    id: 8,
    title: "تقييم الأداء السنوي",
    message: "حان موعد مراجعة تقييم الأداء",
    type: "important",
    time: "منذ 6 ساعات",
    isRead: false,
  },
  {
    id: 9,
    title: "عيد ميلاد زميل",
    message: "اليوم عيد ميلاد محمد العتيبي",
    type: "info",
    time: "منذ 7 ساعات",
    isRead: true,
  },
  {
    id: 10,
    title: "تحديث سياسة الشركة",
    message: "تم تحديث سياسة العمل عن بعد",
    type: "normal",
    time: "منذ 8 ساعات",
    isRead: false,
  },
]

const typeStyles = {
  urgent: "bg-red-50 border-red-200",
  important: "bg-orange-50 border-orange-200",
  normal: "bg-blue-50 border-blue-200",
  info: "bg-green-50 border-green-200",
}

export function Header() {
  const [activeTab, setActiveTab] = useState("عن التجمع")
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [language, setLanguage] = useState<"ar" | "en">("ar")
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false)
  const profileButtonRef = useRef<HTMLButtonElement>(null)
  const profileMenuRef = useRef<HTMLDivElement>(null)
  const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 })

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)
  const notificationsButtonRef = useRef<HTMLButtonElement>(null)
  const notificationsMenuRef = useRef<HTMLDivElement>(null)
  const [notificationsPosition, setNotificationsPosition] = useState({ top: 0, right: 0 })

  const searchButtonRef = useRef<HTMLButtonElement>(null)
  const [searchPosition, setSearchPosition] = useState({ top: 0, left: 0 })

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const tabs = ["عن التجمع", "الإدارات", "الصحة والسلامة", "مركز الابتكار", "مركز المعرفة", "تواصل معنا"]

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "ar" ? "en" : "ar"))
  }

  const handleProfileClick = () => {
    if (profileButtonRef.current) {
      const rect = profileButtonRef.current.getBoundingClientRect()
      setMenuPosition({
        top: rect.bottom + 8,
        left: rect.left,
      })
    }
    setIsProfileMenuOpen(!isProfileMenuOpen)
  }

  const handleNotificationsClick = () => {
    if (notificationsButtonRef.current) {
      const rect = notificationsButtonRef.current.getBoundingClientRect()
      setNotificationsPosition({
        top: rect.bottom + 8,
        right: window.innerWidth - rect.left - 500, // الحافة اليسرى للقائمة = الحافة اليسرى للجرس
      })
    }
    setIsNotificationsOpen(!isNotificationsOpen)
  }

  const handleSearchClick = () => {
    if (searchButtonRef.current) {
      const rect = searchButtonRef.current.getBoundingClientRect()
      setSearchPosition({
        top: rect.bottom + 8,
        left: rect.left,
      })
    }
    setIsSearchOpen(!isSearchOpen)
  }

  const unreadCount = notifications.filter((n) => !n.isRead).length

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case "urgent":
        return <AlertCircle className="w-5 h-5 text-red-600" />
      case "important":
        return <AlertCircle className="w-5 h-5 text-orange-600" />
      case "info":
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case "normal":
        return <Info className="w-5 h-5 text-blue-600" />
      default:
        return <Bell className="w-5 h-5 text-gray-600" />
    }
  }

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileMenuRef.current &&
        !profileMenuRef.current.contains(event.target as Node) &&
        profileButtonRef.current &&
        !profileButtonRef.current.contains(event.target as Node)
      ) {
        setIsProfileMenuOpen(false)
      }
      if (
        notificationsMenuRef.current &&
        !notificationsMenuRef.current.contains(event.target as Node) &&
        notificationsButtonRef.current &&
        !notificationsButtonRef.current.contains(event.target as Node)
      ) {
        setIsNotificationsOpen(false)
      }
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node) && isMobileMenuOpen) {
        setIsMobileMenuOpen(false)
      }
      if (isSearchOpen && searchButtonRef.current && !searchButtonRef.current.contains(event.target as Node)) {
        const searchBox = document.querySelector("[data-search-box]")
        if (searchBox && !searchBox.contains(event.target as Node)) {
          setIsSearchOpen(false)
        }
      }
    }

    if (isProfileMenuOpen || isNotificationsOpen || isMobileMenuOpen || isSearchOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isProfileMenuOpen, isNotificationsOpen, isMobileMenuOpen, isSearchOpen])

  return (
    <>
      {(isProfileMenuOpen || isNotificationsOpen || isSearchOpen) && (
        <div
          className="fixed inset-0 bg-black/20 z-[9998]"
          onClick={() => {
            setIsProfileMenuOpen(false)
            setIsNotificationsOpen(false)
            setIsSearchOpen(false)
          }}
        />
      )}

      <header className="sticky top-0 z-[9999] bg-white/80 backdrop-blur-lg border-b border-[#0088cc]/20 shadow-sm pattern-overlay">
        <div className="max-w-[1600px] mx-auto px-4 md:px-6 py-3 md:py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2 md:gap-4">
              <Link href="/">
                <Image
                  src="/logo.png"
                  alt="تجمع المدينة المنورة الصحي - Madinah Health Cluster"
                  width={200}
                  height={70}
                  className="h-10 md:h-14 w-auto cursor-pointer"
                />
              </Link>
            </div>

            <nav className="hidden lg:flex flex-1 max-w-3xl mx-8">
              <div className="flex items-center justify-center gap-2 w-full">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`
                      px-3 xl:px-5 py-2 xl:py-2.5 rounded-full text-xs xl:text-sm font-semibold transition-all duration-300
                      ${
                        activeTab === tab
                          ? "bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white shadow-lg shadow-[#0088cc]/30"
                          : "text-gray-700 hover:bg-[#0088cc]/10 hover:text-[#0088cc]"
                      }
                    `}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2 md:gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden hover:bg-[#0088cc]/10"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6 text-[#0088cc]" />
                ) : (
                  <Menu className="w-6 h-6 text-gray-600" />
                )}
              </Button>

              {/* Search Button */}
              <div className="relative hidden md:block">
                <Button
                  ref={searchButtonRef}
                  variant="ghost"
                  size="icon"
                  onClick={handleSearchClick}
                  className="hover:bg-[#0088cc]/10"
                >
                  {isSearchOpen ? (
                    <X className="w-7 h-7 text-[#0088cc]" />
                  ) : (
                    <Search className="w-7 h-7 text-gray-600" />
                  )}
                </Button>
              </div>

              {/* Language Toggle - hidden on small mobile */}
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleLanguage}
                className="hidden sm:flex hover:bg-[#0088cc]/10 relative group"
              >
                <Globe className="w-7 h-7 text-gray-600" />
                <span className="absolute -bottom-1 right-1/2 translate-x-1/2 text-[10px] font-bold text-[#0088cc] opacity-0 group-hover:opacity-100 transition-opacity">
                  {language === "ar" ? "EN" : "AR"}
                </span>
              </Button>

              {/* Notifications */}
              <div className="relative">
                <Button
                  ref={notificationsButtonRef}
                  variant="ghost"
                  size="icon"
                  onClick={handleNotificationsClick}
                  className="relative hover:bg-[#0088cc]/10"
                >
                  <Bell className="w-6 md:w-7 h-6 md:h-7 text-gray-600" />
                  {unreadCount > 0 && (
                    <span className="absolute top-0.5 right-0.5 w-5 md:w-5 h-5 md:h-5 bg-red-500 rounded-full flex items-center justify-center text-[9px] md:text-[10px] font-bold text-white animate-pulse">
                      {unreadCount}
                    </span>
                  )}
                </Button>
              </div>

              {/* Profile Menu */}
              <div className="relative">
                <button
                  ref={profileButtonRef}
                  onClick={handleProfileClick}
                  className="w-9 md:w-11 h-9 md:h-11 rounded-full overflow-hidden border-2 border-[#0088cc]/30 hover:border-[#0088cc] transition-all"
                >
                  <Image
                    src="/saudi-man-traditional-thobe-professional.jpg"
                    alt="أحمد المالكي"
                    width={44}
                    height={44}
                    className="w-full h-full object-cover"
                  />
                </button>
              </div>
            </div>
          </div>

          {isMobileMenuOpen && (
            <div className="lg:hidden mt-4 pb-4 animate-in slide-in-from-top-2">
              <nav className="flex flex-col gap-2">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => {
                      setActiveTab(tab)
                      setIsMobileMenuOpen(false)
                    }}
                    className={`
                      px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 text-right
                      ${
                        activeTab === tab
                          ? "bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white shadow-lg shadow-[#0088cc]/30"
                          : "text-gray-700 hover:bg-[#0088cc]/10 hover:text-[#0088cc] bg-white"
                      }
                    `}
                  >
                    {tab}
                  </button>
                ))}
              </nav>

              <div className="mt-4 md:hidden">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="ابحث في البوابة..."
                    className="w-full pr-10 pl-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc]/30 focus:border-[#0088cc] text-right bg-white"
                  />
                </div>
              </div>

              <button
                onClick={toggleLanguage}
                className="sm:hidden mt-2 w-full px-4 py-3 rounded-xl text-sm font-semibold transition-all text-right hover:bg-[#0088cc]/10 hover:text-[#0088cc] bg-white flex items-center justify-between"
              >
                <span className="text-gray-700">تغيير اللغة</span>
                <Globe className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          )}
        </div>
      </header>

      {isSearchOpen && (
        <div
          data-search-box
          className="fixed w-80 bg-white rounded-2xl shadow-2xl border border-[#0088cc]/20 p-4 animate-in slide-in-from-top-2 z-[10000]"
          style={{
            top: `${searchPosition.top}px`,
            left: `${searchPosition.left}px`,
          }}
        >
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="ابحث في البوابة..."
              className="w-full pr-10 pl-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0088cc]/30 focus:border-[#0088cc] text-right"
              autoFocus
            />
          </div>
        </div>
      )}

      {isNotificationsOpen && (
        <div
          ref={notificationsMenuRef}
          className="fixed w-[95vw] sm:w-[500px] max-w-[500px] bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden animate-in slide-in-from-top-2 z-[10000]"
          style={{
            top: `${notificationsPosition.top}px`,
            right: window.innerWidth < 640 ? "2.5vw" : `${notificationsPosition.right}px`,
          }}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0088cc] to-[#006ba3] p-4 flex items-center justify-between">
            <h3 className="text-white font-bold text-lg">الإشعارات</h3>
            <button
              onClick={() => setIsNotificationsOpen(false)}
              className="text-white hover:bg-white/20 rounded-lg p-1 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Notifications List */}
          <div className="max-h-[400px] overflow-y-auto">
            {notifications.slice(0, 10).map((notification) => (
              <div
                key={notification.id}
                className={`p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer ${
                  !notification.isRead ? "bg-blue-50/30" : ""
                }`}
              >
                <div className="flex gap-3">
                  <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-bold text-sm text-gray-900">{notification.title}</h4>
                      {!notification.isRead && (
                        <span className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-1"></span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                    <p className="text-xs text-gray-400 mt-2">{notification.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="p-3 bg-gray-50 border-t border-gray-200">
            <Button variant="ghost" className="w-full text-[#0088cc] hover:bg-[#0088cc]/10 font-semibold">
              عرض جميع الإشعارات
            </Button>
          </div>
        </div>
      )}

      {isProfileMenuOpen && (
        <div
          ref={profileMenuRef}
          className="fixed w-[90vw] sm:w-72 max-w-[288px] bg-white rounded-2xl shadow-2xl border border-[#0088cc]/20 overflow-hidden animate-in slide-in-from-top-2 z-[9999]"
          style={{
            top: `${menuPosition.top}px`,
            left: window.innerWidth < 640 ? "5vw" : `${menuPosition.left}px`,
          }}
        >
          {/* Profile Header */}
          <div className="bg-gradient-to-br from-[#0088cc] to-[#006ba3] p-4">
            <div className="flex items-center gap-3">
              <Image
                src="/saudi-man-traditional-thobe-professional.jpg"
                alt="أحمد المالكي"
                width={50}
                height={50}
                className="w-12 h-12 rounded-full border-2 border-white"
              />
              <div className="text-white">
                <h4 className="font-bold text-sm">أحمد المالكي</h4>
                <p className="text-xs opacity-90">مدير التسويق والاتصال</p>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="p-2">
            <Link href="/profile">
              <button className="w-full text-right px-4 py-3 rounded-xl hover:bg-[#0088cc]/10 transition-colors flex items-center gap-3 group">
                <div className="w-8 h-8 rounded-lg bg-[#0088cc]/10 flex items-center justify-center group-hover:bg-[#0088cc]/20">
                  <User className="w-4 h-4 text-[#0088cc]" />
                </div>
                <span className="font-semibold text-gray-700">صفحتي</span>
              </button>
            </Link>

            <div className="h-px bg-gray-200 my-2"></div>

            <button className="w-full text-right px-4 py-3 rounded-xl hover:bg-red-50 transition-colors flex items-center gap-3 group">
              <div className="w-8 h-8 rounded-lg bg-red-50 flex items-center justify-center group-hover:bg-red-100">
                <LogOut className="w-4 h-4 text-red-600" />
              </div>
              <span className="font-semibold text-red-600">تسجيل الخروج</span>
            </button>
          </div>
        </div>
      )}
    </>
  )
}
