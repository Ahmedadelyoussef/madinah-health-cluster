"use client"

import { useState } from "react"
import { Calendar, ChevronLeft, ChevronRight, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

const events = [
  {
    date: "15",
    month: "مارس",
    title: "اجتماع الإدارة",
    time: "10:00 ص",
    location: "قاعة الاجتماعات",
    color: "#51c041",
  },
  { date: "18", month: "مارس", title: "ورشة عمل التسويق", time: "02:00 م", location: "قاعة التدريب", color: "#009aac" },
  {
    date: "22",
    month: "مارس",
    title: "حفل تكريم الموظفين",
    time: "05:00 م",
    location: "القاعة الكبرى",
    color: "#be008d",
  },
  { date: "25", month: "مارس", title: "دورة تطوير المهارات", time: "09:00 ص", location: "أونلاين", color: "#ff8300" },
]

export function CorporateCalendar() {
  const [currentMonth] = useState("مارس 2024")

  return (
    <div className="bg-gradient-to-br from-[#009aac]/5 to-white rounded-3xl p-6 shadow-lg border border-[#009aac]/20 h-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-[#3e6e2d]">تقويم الفعاليات</h2>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
            <ChevronRight className="w-4 h-4" />
          </Button>
          <span className="text-sm font-medium text-gray-600">{currentMonth}</span>
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-3 max-h-80 overflow-y-auto">
        {events.map((event, index) => (
          <div
            key={index}
            className="group flex gap-4 p-4 rounded-2xl bg-white border border-gray-100 hover:shadow-lg hover:scale-102 transition-all cursor-pointer"
          >
            <div
              className="flex-shrink-0 w-16 h-16 rounded-xl flex flex-col items-center justify-center text-white font-bold shadow-lg"
              style={{ backgroundColor: event.color }}
            >
              <span className="text-2xl">{event.date}</span>
              <span className="text-xs">{event.month}</span>
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-gray-800 mb-1">{event.title}</h3>
              <p className="text-sm text-gray-600 mb-2">{event.time}</p>
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <MapPin className="w-3 h-3" />
                <span>{event.location}</span>
              </div>
            </div>

            <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Calendar className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
