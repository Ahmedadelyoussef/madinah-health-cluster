"use client"

import { useState } from "react"
import {
  FileText,
  Calendar,
  Users,
  Settings,
  Mail,
  Search,
  X,
  Grid3x3,
  CreditCard,
  HelpCircle,
  Lock,
  Laptop,
  Download,
  BarChart3,
  BookOpen,
  Shield,
  DollarSign,
  UserCheck,
  Clock,
  Briefcase,
  Phone,
  Database,
  PieChart,
  FileSpreadsheet,
  Archive,
  Key,
  Bell,
  Wrench,
  FileCheck,
} from "lucide-react"

// All Links with Categories
const allLinks = [
  // HR Services
  { icon: FileText, label: "طلب إجازة", category: "موارد بشرية", color: "#0088cc" },
  { icon: FileCheck, label: "شهادة راتب", category: "موارد بشرية", color: "#0088cc" },
  { icon: UserCheck, label: "شهادة عمل", category: "موارد بشرية", color: "#0088cc" },
  { icon: Clock, label: "طلب استئذان", category: "موارد بشرية", color: "#0088cc" },
  { icon: Briefcase, label: "تحديث البيانات", category: "موارد بشرية", color: "#0088cc" },
  { icon: FileText, label: "طلب تدريب", category: "موارد بشرية", color: "#0088cc" },
  { icon: Users, label: "التأمينات الاجتماعية", category: "موارد بشرية", color: "#0088cc" },
  { icon: Calendar, label: "تقويم الإجازات", category: "موارد بشرية", color: "#0088cc" },

  // Finance
  { icon: CreditCard, label: "كشف الراتب", category: "خدمات مالية", color: "#1fa39b" },
  { icon: DollarSign, label: "طلب سلفة", category: "خدمات مالية", color: "#1fa39b" },
  { icon: FileSpreadsheet, label: "مطالبة مالية", category: "خدمات مالية", color: "#1fa39b" },
  { icon: CreditCard, label: "بدل سكن", category: "خدمات مالية", color: "#1fa39b" },
  { icon: DollarSign, label: "بدل نقل", category: "خدمات مالية", color: "#1fa39b" },
  { icon: FileSpreadsheet, label: "تقرير مصروفات", category: "خدمات مالية", color: "#1fa39b" },

  // IT Support
  { icon: HelpCircle, label: "تذكرة دعم فني", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Laptop, label: "طلب جهاز", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Lock, label: "إعادة تعيين كلمة المرور", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Database, label: "طلب صلاحيات", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Download, label: "تحميل البرامج", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Phone, label: "طلب هاتف", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Wrench, label: "صيانة جهاز", category: "دعم تقني", color: "#5ba0ce" },
  { icon: Shield, label: "الأمن السيبراني", category: "دعم تقني", color: "#5ba0ce" },

  // Reports
  { icon: BarChart3, label: "تقارير الأداء", category: "تقارير", color: "#a8d08d" },
  { icon: PieChart, label: "إحصائيات الحضور", category: "تقارير", color: "#a8d08d" },
  { icon: FileSpreadsheet, label: "تقرير الإجازات", category: "تقارير", color: "#a8d08d" },
  { icon: BarChart3, label: "تقارير مالية", category: "تقارير", color: "#a8d08d" },
  { icon: FileText, label: "تقرير سنوي", category: "تقارير", color: "#a8d08d" },
  { icon: PieChart, label: "تقييم الموظفين", category: "تقارير", color: "#a8d08d" },

  // Settings
  { icon: Settings, label: "إعدادات الحساب", category: "إعدادات", color: "#006ba3" },
  { icon: Bell, label: "إعدادات الإشعارات", category: "إعدادات", color: "#006ba3" },
  { icon: Lock, label: "الخصوصية والأمان", category: "إعدادات", color: "#006ba3" },
  { icon: Key, label: "تغيير كلمة المرور", category: "إعدادات", color: "#006ba3" },

  // Knowledge
  { icon: BookOpen, label: "دليل الموظف", category: "مكتبة المعرفة", color: "#8fc8df" },
  { icon: FileText, label: "السياسات والإجراءات", category: "مكتبة المعرفة", color: "#8fc8df" },
  { icon: Archive, label: "الأرشيف", category: "مكتبة المعرفة", color: "#8fc8df" },
  { icon: Database, label: "قاعدة المعرفة", category: "مكتبة المعرفة", color: "#8fc8df" },
  { icon: BookOpen, label: "مواد تدريبية", category: "مكتبة المعرفة", color: "#8fc8df" },

  // Other
  { icon: Mail, label: "البريد الإلكتروني", category: "أدوات عامة", color: "#0088cc" },
  { icon: Calendar, label: "التقويم", category: "أدوات عامة", color: "#0088cc" },
]

export function QuickLinks() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("الكل")

  const categories = ["الكل", ...Array.from(new Set(allLinks.map((link) => link.category)))]

  const filteredLinks = allLinks.filter((link) => {
    const matchesSearch = link.label.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "الكل" || link.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const topLinks = [
    { icon: FileText, label: "خدمات الموظفين", color: "#0088cc" },
    { icon: Calendar, label: "التقويم", color: "#1fa39b" },
    { icon: Users, label: "دليل الموظفين", color: "#5ba0ce" },
    { icon: Settings, label: "الإعدادات", color: "#a8d08d" },
    { icon: Mail, label: "البريد الإلكتروني", color: "#006ba3" },
    { icon: HelpCircle, label: "الدعم الفني", color: "#8fc8df" },
  ]

  return (
    <>
      {/* Compact View */}
      <div className="bg-white rounded-3xl p-4 md:p-6 shadow-lg border border-gray-100 pattern-overlay">
        <div className="flex items-center justify-between mb-4 md:mb-6 gap-2">
          <h2 className="text-lg md:text-2xl font-bold text-[#006ba3]">روابط سريعة</h2>
          <button
            onClick={() => setIsMenuOpen(true)}
            className="flex items-center gap-1 md:gap-2 px-3 md:px-5 py-2 md:py-2.5 rounded-xl bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white hover:shadow-xl hover:scale-105 transition-all whitespace-nowrap"
          >
            <Grid3x3 className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-xs md:text-sm font-bold">جميع الخدمات</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 md:gap-4">
          {topLinks.map((link, index) => {
            const Icon = link.icon
            return (
              <button
                key={index}
                className="group relative p-2 md:p-4 rounded-2xl bg-gradient-to-br from-white to-gray-50 border border-gray-100 hover:shadow-xl hover:scale-105 hover:-translate-y-1 transition-all duration-300"
              >
                <div
                  className="w-12 h-12 md:w-16 md:h-16 rounded-2xl flex items-center justify-center mb-2 md:mb-3 mx-auto group-hover:scale-110 transition-transform shadow-sm"
                  style={{ backgroundColor: `${link.color}20` }}
                >
                  <Icon className="w-6 h-6 md:w-8 md:h-8" style={{ color: link.color }} />
                </div>
                <p className="text-xs md:text-sm font-bold text-gray-800 text-center leading-tight">{link.label}</p>
              </button>
            )
          })}
        </div>
      </div>

      {isMenuOpen && (
        <div className="fixed inset-0 z-[10001] bg-black/50 backdrop-blur-sm flex items-center justify-center p-2 md:p-4">
          <div className="bg-white rounded-3xl w-full max-w-7xl max-h-[90vh] overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="bg-gradient-to-r from-[#0088cc] via-[#006ba3] to-[#0088cc] p-4 md:p-6 text-white">
              <div className="flex items-center justify-between mb-3 md:mb-4">
                <h2 className="text-xl md:text-3xl font-bold">جميع الخدمات</h2>
                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 flex items-center justify-center transition-all"
                >
                  <X className="w-5 h-5 md:w-6 md:h-6" />
                </button>
              </div>

              {/* Search Box */}
              <div className="relative">
                <Search className="absolute right-3 md:right-4 top-1/2 transform -translate-y-1/2 w-4 h-4 md:w-5 md:h-5 text-white/60" />
                <input
                  type="text"
                  placeholder="ابحث عن خدمة..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pr-10 md:pr-12 pl-3 md:pl-4 py-2 md:py-3 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 text-sm md:text-base text-white placeholder-white/60 focus:bg-white/30 focus:outline-none transition-all"
                />
              </div>
            </div>

            {/* Category Filters */}
            <div className="px-3 md:px-6 py-3 md:py-4 border-b border-gray-100 bg-gray-50 overflow-x-auto">
              <div className="flex flex-nowrap md:flex-wrap gap-2 min-w-max md:min-w-0">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-3 md:px-4 py-1.5 md:py-2 rounded-xl text-xs md:text-sm font-semibold transition-all whitespace-nowrap ${
                      selectedCategory === category
                        ? "bg-gradient-to-r from-[#0088cc] to-[#006ba3] text-white shadow-lg"
                        : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Services Grid */}
            <div className="p-3 md:p-6 overflow-y-auto max-h-[calc(90vh-240px)] md:max-h-[calc(90vh-280px)]">
              {filteredLinks.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
                  {filteredLinks.map((link, index) => {
                    const Icon = link.icon
                    return (
                      <button
                        key={index}
                        onClick={() => setIsMenuOpen(false)}
                        className="group p-3 md:p-4 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-100 hover:shadow-xl hover:scale-105 transition-all duration-300"
                      >
                        <div
                          className="w-12 h-12 md:w-16 md:h-16 rounded-2xl flex items-center justify-center mb-2 md:mb-3 mx-auto group-hover:scale-110 transition-transform"
                          style={{ backgroundColor: `${link.color}20` }}
                        >
                          <Icon className="w-6 h-6 md:w-8 md:h-8" style={{ color: link.color }} />
                        </div>
                        <p className="text-xs md:text-sm font-bold text-gray-800 text-center mb-1 leading-tight">
                          {link.label}
                        </p>
                        <p className="text-[10px] md:text-xs text-gray-500 text-center">{link.category}</p>
                      </button>
                    )
                  })}
                </div>
              ) : (
                <div className="text-center py-8 md:py-12">
                  <Search className="w-12 h-12 md:w-16 md:h-16 text-gray-300 mx-auto mb-3 md:mb-4" />
                  <p className="text-gray-500 text-base md:text-lg">لا توجد نتائج للبحث</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
