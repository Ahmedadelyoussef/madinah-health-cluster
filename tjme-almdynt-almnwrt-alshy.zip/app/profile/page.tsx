"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { NotificationCenter } from "@/components/profile/notification-center"
import { ProfileHeader } from "@/components/profile/profile-header"
import { ProfileTabs } from "@/components/profile/profile-tabs"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8faf9] to-white" dir="rtl">
      <Header />

      <main className="pb-12">
        {/* Notification Center */}
        <div className="bg-white border-b border-gray-100">
          <div className="max-w-[1400px] mx-auto px-6 py-4">
            <NotificationCenter />
          </div>
        </div>

        {/* Profile Content */}
        <div className="max-w-[1400px] mx-auto px-6 mt-8">
          {/* Profile Header */}
          <ProfileHeader />

          {/* Tabs and Content */}
          <div className="mt-8">
            <ProfileTabs />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
