"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { HeroBanner } from "@/components/hero-banner"
import { NotificationsBanner } from "@/components/notifications-banner"
import { CEOMessage } from "@/components/ceo-message"
import { InternalNews } from "@/components/internal-news"
import { OrganizationChart } from "@/components/organization-chart"
import { QuickLinks } from "@/components/quick-links"
import { VotingSurvey } from "@/components/voting-survey"
import { TodoList } from "@/components/todo-list"
import { CorporateCalendar } from "@/components/corporate-calendar"
import { MultimediaGallery } from "@/components/multimedia-gallery"
import { MeetingRooms } from "@/components/meeting-rooms"
import { BirthdayMessages } from "@/components/birthday-messages"
import { EmployeeRecognition } from "@/components/employee-recognition"
import { NewComers } from "@/components/new-comers"
import { DigitalOnboard } from "@/components/digital-onboard"
import { Resources } from "@/components/resources"
import { DepartmentSpaces } from "@/components/department-spaces"
import { StaffOffers } from "@/components/staff-offers"
import { Projects } from "@/components/projects"
import { WeatherPrayer } from "@/components/weather-prayer"
import { DiscussionBoard } from "@/components/discussion-board"
import { TeamsMockup } from "@/components/teams-mockup"
import { Footer } from "@/components/footer"

export default function Home() {
  const [isSyncing, setIsSyncing] = useState(false)

  const handleSync = async () => {
    setIsSyncing(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsSyncing(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8faf9] to-white pb-20" dir="rtl">
      <Header onSync={handleSync} isSyncing={isSyncing} />

      <main className="pb-8 md:pb-12">
        <HeroBanner />

        {/* Bento Grid Layout - Added responsive padding and gap */}
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 space-y-4 sm:space-y-6 md:space-y-8 mt-4 sm:mt-6 md:mt-8">
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12">
              <NotificationsBanner />
            </div>
          </div>

          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12">
              <CEOMessage />
            </div>
          </div>

          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12">
              <QuickLinks />
            </div>
          </div>

          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 lg:col-span-5">
              <WeatherPrayer />
            </div>
            <div className="col-span-12 lg:col-span-7">
              <InternalNews />
            </div>
          </div>

          {/* Discussion Board and Teams */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 lg:col-span-7">
              <DiscussionBoard />
            </div>
            <div className="col-span-12 lg:col-span-5">
              <TeamsMockup />
            </div>
          </div>

          {/* Row 2: Organization Chart */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12">
              <OrganizationChart />
            </div>
          </div>

          {/* Row 3: Voting + Todo + Calendar */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 md:col-span-6 lg:col-span-4">
              <VotingSurvey />
            </div>
            <div className="col-span-12 md:col-span-6 lg:col-span-4">
              <TodoList />
            </div>
            <div className="col-span-12 md:col-span-12 lg:col-span-4">
              <CorporateCalendar />
            </div>
          </div>

          {/* Row 4: Multimedia Gallery */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12">
              <MultimediaGallery />
            </div>
          </div>

          {/* Row 5: Meeting Rooms + Birthday Messages */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 lg:col-span-7">
              <MeetingRooms />
            </div>
            <div className="col-span-12 lg:col-span-5">
              <BirthdayMessages />
            </div>
          </div>

          {/* Row 6: Employee Recognition + New Comers */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 lg:col-span-6">
              <EmployeeRecognition />
            </div>
            <div className="col-span-12 lg:col-span-6">
              <NewComers />
            </div>
          </div>

          {/* Row 7: Digital Onboard */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12">
              <DigitalOnboard />
            </div>
          </div>

          {/* Row 8: Resources + Department Spaces */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 lg:col-span-5">
              <Resources />
            </div>
            <div className="col-span-12 lg:col-span-7">
              <DepartmentSpaces />
            </div>
          </div>

          {/* Row 9: Staff Offers + Projects */}
          <div className="grid grid-cols-12 gap-4 sm:gap-6">
            <div className="col-span-12 lg:col-span-6">
              <StaffOffers />
            </div>
            <div className="col-span-12 lg:col-span-6">
              <Projects />
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  )
}
